# Content DNA

## Goal

Describe what the agent wants people to know, feel, learn, or remember after following the agent.

## Platforms

Facebook:

Instagram:

TikTok:

YouTube:

LinkedIn:

Email:

Other:

## Content pillars

List the agent's professional, local, personal, educational, community, and lifestyle pillars.

## Suggested balance

Real estate education:

Local content:

Personal brand:

Stories:

Community:

Direct business generation:

The percentages should reflect the actual agent.

## Tone

Describe the desired tone and the amount of humor, opinion, storytelling, directness, and personal content.

## Calls to action

List calls to action that feel natural.

## Subjects to avoid

List private, political, personal, or professional subjects the agent does not want AI to use.

## Repetition rules

Before creating content, review `CONTENT_HISTORY.md` when available.

Avoid repeating recent:

1. Hooks

2. Stories

3. Topics

4. Calls to action

5. Formats

6. Listing angles

7. Mortgage content

## Final test

Before publishing, ask:

1. Does this sound like the agent?

2. Is there a real idea?

3. Is every factual claim supported?

4. Does the post need a call to action?

5. Is the topic too similar to recent content?

6. Did the writing stop when the point was finished?
