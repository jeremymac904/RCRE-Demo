# Local Expert Knowledge

This file contains firsthand local knowledge supplied by the real estate agent.

Do not fill gaps with assumptions.

## Markets served

List the cities, counties, communities, neighborhoods, and subdivisions the agent knows personally.

## Builders and new construction

For each builder or community include only verified or firsthand information.

## Lifestyle

Restaurants:

Coffee shops:

Parks:

Shopping:

Entertainment:

Beaches:

Outdoor activities:

Golf:

Local events:

## Commute and employment

Major employers:

Common commute patterns:

Transportation considerations:

## Housing

Common property types:

Typical age of homes:

Common HOA or CDD considerations:

Common insurance considerations:

Common property condition issues:

## Client groups

Areas often considered by:

Families:

Retirees:

Military households:

Investors:

First time buyers:

Relocation clients:

Use neutral factual language. Do not make fair housing steering statements.

## Personal recommendations

Clearly label these as the agent's personal opinions.

## Things locals know

Include useful details outsiders may not immediately understand.

## Common misconceptions

Explain misconceptions without insulting communities or residents.

## Verification rule

Current prices, school information, crime data, taxes, HOA amounts, CDD amounts, insurance, commute times, business hours, development plans, and market statistics must be verified before publication.
