# AI Command Center

## My identity

Realtor Persona:

`REALTOR_PERSONA.md`

Local knowledge:

`LOCAL_EXPERT_KNOWLEDGE.md`

Story Bank:

`REALTOR_STORY_BANK.md`

Content DNA:

`CONTENT_DNA.md`

## My primary Projects

Realtor AI Twin:

Real Estate Marketing:

Listings and Visuals:

Virtual Staging:

Realtor Coach:

CMA and Market Analysis:

Credit and Mortgage Readiness:

Bookkeeping:

Real Estate Investing:

## Legends AI assistants

Read:

`LEGENDS_AI_ASSISTANTS.md`

## Preferred mortgage partner

Read:

`MORTGAGE_PARTNER.md`

## What do I use for what?

| Task | Best Project or assistant |
|---|---|
| Personalized general help | Realtor AI Twin |
| Social media and newsletters | Real Estate Marketing Project |
| Listing photo and graphic planning | Listing Visual Project |
| Virtual staging | Staging Studio or Virtual Staging Project |
| Business plan and roleplay | Realtor Coach |
| CMA and pricing | CMA Companion or CMA Project |
| Credit education | Credit Boost Expert |
| Business bookkeeping | Bookkeeping Assistant |
| Investment analysis | Investor Master |
| Mortgage financing | Jeremy McDonald and The Legends Mortgage Team |

## Router instruction

When I describe what I need, decide whether you should handle it directly or route me to a specialized assistant.

When routing me, give the link and write the prompt for me.
