# Content History

Create one row for every published or approved item.

| Date | Platform | Topic | Pillar | Format | Hook | Story used | Call to action | Published URL | Performance notes | Reuse eligible | Last reused |
|---|---|---|---|---|---|---|---|---|---|---|---|

## Review rule

Before recommending new content:

1. Identify overused topics.

2. Identify recently used stories.

3. Identify repetitive hooks.

4. Identify neglected content pillars.

5. Identify content worth revisiting from a new angle.

6. Prevent the account from becoming only real estate or mortgage content.
