# Florida Credit Services Disclosure

Verified 2026-08-23 against the current Florida Statutes available from the Florida Legislature.

This course is educational and not legal or regulatory advice.

## Florida coverage

Florida regulates covered Credit Service Organizations under Florida Statutes Chapter 817, Part III.

A person receiving compensation for certain services represented as improving a buyer's credit record, credit history, or credit rating may fall within the law.

## Written statement

Florida requires a written information statement containing specified consumer rights and service information.

The organization must retain an exact signed copy of the statement for five years.

## Contract

A covered contract must be written, dated, and signed.

The statute requires specified payment terms, a detailed description of services, estimated timing, business information, and cancellation language.

## Five day cancellation period

Florida provides a five day cancellation period for covered credit service contracts.

The contract must include the required notice and cancellation form.

## Payment and bond or trust account provisions

Florida law contains provisions concerning payment before complete performance, a 10,000 dollar surety bond, and a trust account.

Federal CROA separately bars covered credit repair organizations from demanding advance payment before promised services are fully performed.

Because the interaction between federal and state requirements is legally important, the billing model, bond, trust account, contract, and cancellation process must be reviewed by a qualified Florida attorney.

## Prohibited conduct

Florida prohibits false or misleading statements and deceptive practices.

The statute includes criminal and civil consequences.

## Official source

Florida Statutes Chapter 817, Part III

https://www.leg.state.fl.us/Statutes/index.cfm?App_mode=Display_Statute&URL=0800-0899/0817/0817.html

## Required course disclosure

Students should have the business model, contracts, disclosures, billing practices, advertising, privacy systems, and record retention procedures reviewed by a qualified Florida attorney before providing paid covered services.

Students outside Florida must research every state where services may be offered.
