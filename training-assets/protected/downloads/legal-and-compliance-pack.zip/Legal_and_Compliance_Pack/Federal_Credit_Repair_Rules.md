# Federal Credit Repair Rules

Verified 2026-08-23 against official Federal Trade Commission materials.

This is educational material and not legal or regulatory advice.

## Credit Repair Organizations Act

The federal Credit Repair Organizations Act governs covered credit repair services.

The Federal Trade Commission explains that the Act:

1. Prohibits untrue or misleading representations.

2. Requires specified disclosures.

3. Requires covered contracts to be in writing.

4. Gives consumers cancellation rights.

5. Bars covered credit repair organizations from demanding advance payment before the promised services are fully performed.

## Prohibited claims and conduct

A business must not:

1. Promise removal of accurate and timely negative information.

2. Guarantee a specific credit score increase.

3. Encourage consumers to dispute information known to be accurate.

4. Create false identity theft claims.

5. Create false documents.

6. Promote a CPN or alternate identity scheme.

7. Misrepresent the company's credentials, services, outcomes, or legal authority.

8. Charge in advance contrary to applicable federal law.

## Contracts and cancellation

Federal law requires specific written disclosures and contract terms for covered services.

The federal cancellation period is generally three business days.

Florida provides a longer five day cancellation period for covered Florida credit service contracts.

The actual business documents must be reviewed by a qualified attorney.

## Telemarketing

The Federal Trade Commission Telemarketing Sales Rule can create additional requirements and payment restrictions when credit repair services are marketed or sold through telemarketing.

Do not launch outbound calling, purchased lead, or telephone sales campaigns without current legal review.

## Official sources

1. Federal Trade Commission Credit Repair Organizations Act page

https://www.ftc.gov/legal-library/browse/statutes/credit-repair-organizations-act

2. Federal Trade Commission business guidance

https://www.ftc.gov/business-guidance/blog/2019/06/ftc-says-credit-repair-company-en-croa-ched-consumer-rights

3. Federal Trade Commission Telemarketing Sales Rule guidance

https://www.ftc.gov/business-guidance/resources/complying-telemarketing-sales-rule

4. Consumer Financial Protection Bureau credit report resources

https://www.consumerfinance.gov/consumer-tools/credit-reports-and-scores/

## Course rule

Before accepting a credit services client:

1. Verify whether the business is covered.

2. Verify federal and state requirements.

3. Have contracts and disclosures reviewed.

4. Have billing practices reviewed.

5. Use secure systems.

6. Review all marketing claims.

7. Create a complaint and record retention process.

8. Never treat a private course certificate as government authorization to operate.
