# Legal and Compliance Pack

Reference material for the AI Advantage bonus business tracks.

**This is educational material. It is not legal, tax, accounting, licensing, cybersecurity, or regulatory advice.**

Every file carries the date it was verified against primary sources. Federal and state requirements, IRS fees, continuing-education hours, and filing thresholds change on annual cycles. Re-verify before you rely on any of it, and have a qualified attorney review your actual business documents.

## Contents

- `AI_Data_Security_Rules.md`
- `Federal_Credit_Repair_Rules.md`
- `Federal_Tax_Preparer_Requirements.md`
- `Florida_Credit_Services_Disclosure.md`
- `Florida_and_Multistate_Tax_Disclosure.md`
- `Mortgage_Marketing_and_Referral_Guardrails.md`