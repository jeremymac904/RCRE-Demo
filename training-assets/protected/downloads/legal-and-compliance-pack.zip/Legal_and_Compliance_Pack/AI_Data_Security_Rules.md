# AI Data Security Rules

## Never place these items into ordinary AI chats or project folders

1. Social Security numbers

2. Bank account numbers

3. Passwords

4. Authentication codes

5. Complete unredacted credit reports

6. Complete unredacted tax returns

7. Driver license numbers

8. Passport numbers

9. Private medical information

10. Private legal documents without authorization and an approved environment

11. Borrower documents containing sensitive identifiers

12. Client information the user is not authorized to share

## Training rule

Use synthetic examples or properly redacted files.

## Operational rule

Sensitive tax, credit, mortgage, legal, or financial work must use approved systems with appropriate access controls, encryption, retention, vendor review, and incident response.

A tool accepting an upload does not automatically mean the tool is approved for that data.

## Minimum controls for a real business

1. Written security policies

2. Multifactor authentication

3. Least privilege access

4. Approved devices

5. Secure storage

6. Secure transmission

7. Vendor review

8. Backups

9. Data retention and disposal

10. Incident response

11. Staff training

12. Periodic review

## AI assistant behavior

When a request appears to include sensitive information:

1. Stop.

2. Tell the user what should be redacted.

3. Request a redacted or synthetic version.

4. Do not repeat sensitive information back.

5. Do not store it in a permanent knowledge file.

6. Route the user to an approved secure system when operational processing is necessary.
