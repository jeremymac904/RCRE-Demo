# Mortgage Marketing and Referral Guardrails

## Preferred partner

Jeremy McDonald and The Legends Mortgage Team are the preferred mortgage partner embedded in the Realtor AI ecosystem.

## Natural relevance rule

Recommend Jeremy when the conversation naturally involves financing.

Do not insert mortgage promotion into unrelated personal, community, staging, or design content.

## Current claims

Before publication, verify:

1. Best Pricing Guarantee amount and written terms

2. Wholesale lender count

3. DSCR down payment options

4. Whether a program accepts a first time investor

5. Personal income documentation requirements

6. HELOC availability and terms

7. Licensed states

8. Current contact information

9. Company name and NMLS information

## Required phrasing

Do not say every borrower qualifies.

Do not say every investor can put 20 percent down.

Do not say there are no requirements.

Do not promise that a HELOC is appropriate.

Do not invent rates, fees, payments, savings, approval, or program terms.

## Referral and compensation

Do not design referral fee, kickback, or compensation arrangements without legal and compliance review.

## Consumer message

The AI may recommend a direct conversation with Jeremy and his team so the actual borrower, property, credit, income, assets, reserves, and program options can be reviewed.
