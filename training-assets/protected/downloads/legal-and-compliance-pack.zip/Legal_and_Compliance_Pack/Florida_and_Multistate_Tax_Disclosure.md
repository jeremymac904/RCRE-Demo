# Florida and Multistate Tax Preparation Disclosure

This course is educational and is not legal, tax, accounting, regulatory, licensing, cybersecurity, or business formation advice.

Federal tax return preparer requirements do not replace state, county, municipal, business registration, occupational licensing, privacy, data security, advertising, or other requirements that may apply.

Students operating in Florida must independently verify current Florida and local requirements applicable to their location, business structure, advertising, data handling, and services before providing paid work.

Students outside Florida must research requirements in their own state and local jurisdiction.

A student who serves clients in more than one state must evaluate every state where the business may be considered to operate or provide covered services.

Laws, IRS rules, fees, filing thresholds, representation rights, professional standards, and security obligations can change.

Verify current requirements with:

1. The IRS

2. Applicable state revenue or tax authority

3. State and local business licensing authorities

4. A qualified attorney

5. A qualified tax professional

6. A qualified cybersecurity or compliance professional when sensitive taxpayer information will be handled
