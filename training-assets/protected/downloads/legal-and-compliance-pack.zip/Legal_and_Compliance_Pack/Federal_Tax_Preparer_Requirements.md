# Federal Tax Preparer Requirements

Verified 2026-08-23 against official IRS and Taxpayer Advocate Service information.

This is educational material and not legal, tax, accounting, licensing, or regulatory advice.

## PTIN

A person who is paid to prepare, or help prepare, all or substantially all of a federal tax return or certain other IRS forms generally needs a valid Preparer Tax Identification Number.

A PTIN must be renewed annually.

Verify the current application or renewal fee directly with the IRS because fees can change.

## Annual Filing Season Program

The Annual Filing Season Program is voluntary.

Non credentialed preparers who meet the current IRS education and participation requirements may receive an IRS Record of Completion, limited representation rights, and public directory eligibility.

The standard path has historically included up to 18 hours of IRS approved continuing education, including a federal tax refresher component, other federal tax law, and ethics. Verify the current requirements before publication or enrollment.

## Enrolled Agent

Enrolled Agent is a federal tax credential with broader IRS representation rights.

It is not the same as holding only a PTIN or participating in the Annual Filing Season Program.

## Electronic filing and EFIN

A PTIN identifies the paid preparer.

An Electronic Filing Identification Number is associated with an authorized IRS electronic filing provider.

A preparer or firm that wants to electronically file returns for clients may need to apply through the IRS electronic filing provider process.

The IRS states that the application review can take up to 45 days.

Federal electronic filing requirements can apply when a preparer reasonably expects to file 11 or more covered returns. Verify the current rule, definitions, and exceptions with the IRS.

## Data security

Tax professionals are required to protect taxpayer data.

IRS guidance states that tax professionals must have a Written Information Security Plan under federal data safeguard requirements.

A real business also needs secure client intake, approved tax software, access controls, multifactor authentication, vendor review, backups, incident response, data disposal, and a recovery plan appropriate to the operation.

## Official sources

1. PTIN overview

https://www.taxpayeradvocate.irs.gov/get-help/general/getting-a-ptin/

2. Annual Filing Season Program

https://www.irs.gov/tax-professionals/annual-filing-season-program

3. IRS electronic filing provider application

https://www.irs.gov/pub/irs-access/p3112_accessible.pdf

4. IRS data safeguard guidance

https://www.irs.gov/newsroom/filing-season-readiness-for-tax-pros-review-data-safeguards

5. IRS Publication 4557, Safeguarding Taxpayer Data

https://www.irs.gov/pub/irs-pdf/p4557.pdf

## Course rule

Before a student offers paid tax preparation:

1. Verify current federal requirements.

2. Verify state and local business requirements.

3. Obtain appropriate education.

4. Use approved secure systems.

5. Define the scope of returns the student is competent to prepare.

6. Obtain professional review where necessary.

7. Never represent the student as a CPA, Enrolled Agent, attorney, or other credentialed professional unless that credential is true.
