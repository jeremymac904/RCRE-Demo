# Virtual Staging Studio Prompt Library

Use these prompts during the walkthroughs and inside the matching student Project.

## Lesson 1, The Golden Rule of Virtual Staging

### Master preservation prompt

```text
Use the uploaded photograph as the exact architectural reference.

Preserve the property as photographed.

Do not change:

Walls

Windows

Doors

Flooring

Ceiling

Cabinetry

Counters

Fireplace

Lighting fixtures

Built ins

Room dimensions

Architectural details

Camera position

Camera angle

Window views

Only add or change removable furniture, rugs, artwork, plants, lamps, and decor.

Maintain realistic scale, perspective, lighting, shadows, reflections, and depth.

The final image should look like professional real estate photography of the same exact room after physical staging.
```

## Lesson 2, Stage a Vacant Living Room

### Living room

```text
Virtually stage this vacant living room.

Preserve every permanent property feature exactly as photographed.

Style:

Warm contemporary.

Add:

A properly scaled sofa

Two complementary accent chairs if the room size supports them

Coffee table

Area rug

Side tables

Simple lamps

Subtle wall art

A small amount of greenery

Keep walking paths open.

Do not overcrowd the room.

Do not block windows, doors, fireplaces, or architectural features.

Do not change the property.

Make the result look like professional physical staging photographed with the same camera.
```

## Lesson 3, Stage a Bedroom

### Bedroom

```text
Virtually stage this vacant bedroom.

Preserve the exact architecture and permanent property features.

Create a comfortable modern bedroom using furniture appropriate for the actual size of the room.

Add:

Properly scaled bed

Nightstands

Lamps

Simple bedding

Area rug if appropriate

Minimal artwork

Small amount of decor

Do not block windows, doors, closets, or walkways.

Do not change the room dimensions.

Do not enlarge the room.

Do not alter flooring, walls, windows, lighting fixtures, or architectural details.

Keep the staging realistic and appropriate for real estate marketing.
```

## Lesson 4, Dining Rooms and Flex Spaces

### Dining room

```text
Virtually stage this room as a dining room.

Preserve all permanent property features.

Use a dining table and chairs appropriately scaled to the available space.

Add minimal decor, a simple centerpiece, artwork, and a rug only if appropriate.

Do not replace or add permanent lighting fixtures.

Do not change walls, flooring, doors, windows, or room dimensions.

Maintain realistic walking space around the furniture.
```

### Home office

```text
Virtually stage this room as a functional home office.

Preserve all permanent property features exactly as photographed.

Add:

Desk

Office chair

Small shelving or storage if space allows

Simple artwork

Minimal decor

Small plant

Do not make structural changes.

Do not imply built in cabinetry or permanent features that do not exist.

Keep the room realistic and uncluttered.
```

## Lesson 5, Try Multiple Design Styles

### Three styles

```text
Using the exact same original room photograph, create three separate virtual staging concepts.

Version one:

Modern coastal.

Version two:

Warm contemporary.

Version three:

Transitional luxury.

For every version:

Preserve all permanent property features exactly.

Use furniture appropriate for the room dimensions.

Maintain the original camera angle.

Maintain the original room proportions.

Maintain realistic lighting and shadows.

Do not change architecture.

Do not change flooring.

Do not change fixtures.

Do not change window views.

Only furniture and removable decor may change.
```

## Lesson 6, Furniture Removal

### Remove furniture

```text
Remove all removable furniture and decor from this room.

Create a realistic vacant version of the exact same room.

Preserve:

Walls

Doors

Windows

Flooring

Ceiling

Lighting fixtures

Cabinetry

Built ins

Fireplace

Permanent architectural features

Camera angle

Room dimensions

Do not renovate anything.

Do not repair or replace materials.

Do not add anything.

The final result should look like the same room photographed completely vacant.
```

## Lesson 7, Decluttering Without Redesigning

### Declutter

```text
Clean up this room for real estate marketing.

Remove only obvious temporary clutter and excessive personal items.

Examples may include:

Loose papers

Excess countertop items

Small miscellaneous objects

Temporary storage items

Personal photographs

Excessive decorative clutter

Preserve furniture unless I specifically request removal.

Preserve every permanent property feature.

Do not renovate.

Do not replace finishes.

Do not make the property appear newer than it actually is.

The goal is simply a cleaner presentation of the same room.
```

## Lesson 8, Outdoor Staging

### Outdoor living area

```text
Virtually stage this outdoor living area.

Preserve the actual patio, lanai, deck, pool, landscaping, fencing, structure, views, and architecture exactly as photographed.

Add removable outdoor furniture appropriate for the available space.

Possible items:

Outdoor seating

Small dining set

Outdoor rug

Removable planters

Simple table decor

Do not add:

Pools

Fire pits

Outdoor kitchens

Permanent pergolas

Fencing

Hardscaping

Landscaping features

Or any permanent improvement that does not already exist.

Keep the result realistic and appropriate for real estate marketing.
```

## Lesson 9, Fixing Bad AI Generations

### Restore architecture

```text
Compare your generated image against the original property photograph.

You changed permanent property features.

Correct the image.

Restore the original:

Window placement

Door placement

Flooring

Walls

Fixtures

Architecture

Room dimensions

Camera angle

Do not change the furniture concept unless necessary.

Only correct the inaccurate property features.
```

### Fix furniture scale

```text
The furniture scale is unrealistic.

Keep the property exactly unchanged.

Reduce the furniture size so it realistically fits the room.

Maintain comfortable walking paths.

Do not change architecture, room dimensions, or camera perspective.

Fix only the furniture scale and placement.
```

### Fix malformed objects

```text
Review the staged image for visual errors.

Look specifically for:

Malformed furniture

Extra furniture legs

Distorted objects

Floating objects

Incorrect shadows

Objects intersecting walls

Objects blocking doors

Objects blocking windows

Unrealistic reflections

Fix only those errors.

Preserve the property and overall staging style.
```

## Lesson 10, Let the Twin Build the Staging Prompt

### Vacant room routing

```text
I have a vacant living room in a new listing.

The house has a coastal feel and I want the room virtually staged without changing any property features.

Help me use the correct Legends AI assistant.
```

### Furniture replacement routing

```text
My seller has a furnished living room but the furniture makes the room look smaller than it really is.

I want to remove the existing furniture and virtually stage the room with something more appropriate.

Tell me which Legends AI tool to use and create the exact prompt for me.
```

## Lesson 11, Disclosure and Advertising Accuracy

### Accuracy review

```text
Before approving any AI modified real estate image, compare it against the original photograph.

Flag anything that:

Changes architecture

Changes permanent materials

Changes room dimensions

Creates permanent improvements

Removes permanent defects

Creates fake views

Changes landscaping materially

Misrepresents property condition

Could reasonably cause a buyer to misunderstand what physically exists

When required by MLS, brokerage, state, advertising, or platform rules, clearly disclose that the image has been virtually staged or modified using AI.

When uncertain, require human review before publication.
```

## Lesson 12, Create a Complete Staging Set

### Whole property staging plan

```text
I am going to upload multiple vacant room photographs from the same property.

First analyze all photographs.

Do not generate anything yet.

Recommend one consistent staging style for the entire property based on:

Architecture

Finishes

Property type

Room proportions

Location if provided

Likely buyer audience

Then tell me:

Which rooms should be staged

Which rooms should remain vacant

Furniture style

Color palette

Decor style

Anything that should remain visually consistent across every room

After I approve the direction, create individual staging prompts for every room.

Each prompt must preserve the original architecture and permanent property features.
```

## Lesson 13, Before and After Marketing

### Before and after graphic

```text
Create a social media concept showing the original vacant room beside the virtually staged version.

Clearly label:

ACTUAL ROOM

VIRTUALLY STAGED

Keep both images large enough to compare.

Do not imply that the furniture is included with the property.

Use a clean professional real estate layout.

Include my name and contact information using my Realtor Persona.

Do not cover important architectural features.
```

## Lesson 14, Build the Virtual Staging Project

### Project instruction

```text
You are my Virtual Staging Assistant.

Before personalized work, read:

REALTOR_PERSONA.md

Then read:

STAGING_RULES.md

STAGING_STYLES.md

LEGENDS_AI_ASSISTANTS.md

The original property photographs are the source of truth.

Never overwrite original photographs.

Never invent permanent property features.

Never alter architecture unless I explicitly ask for a clearly labeled proposed renovation concept that is not being represented as the current property.

For normal virtual staging:

Preserve permanent property features.

Only modify removable furniture and decor.

Maintain realistic scale.

Maintain realistic perspective.

Maintain realistic lighting.

Maintain the original room dimensions and camera angle.

When another Legends AI assistant is better suited for a task, use LEGENDS_AI_ASSISTANTS.md and provide me the direct link and exact prompt.

If an edit could materially misrepresent the property, flag it for human review.
```
