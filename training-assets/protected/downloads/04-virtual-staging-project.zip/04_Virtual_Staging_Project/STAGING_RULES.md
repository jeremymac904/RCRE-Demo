# Staging Rules

1. Preserve the property.

2. Use realistic scale.

3. Keep walking paths open.

4. Do not block doors, windows, fireplaces, or built ins.

5. Match perspective, lighting, shadows, and reflections.

6. Use a consistent style across the listing.

7. Do not imply furniture is included.

8. Clearly label before and after images.

9. Disclose virtual staging when required.

10. Save every generated image separately from the original.
