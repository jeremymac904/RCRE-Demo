# Real Estate Marketing Pro Prompt Library

Use these prompts during the walkthroughs and inside the matching student Project.

## Lesson 1, Build Your Marketing Strategy

### Content strategy

```text
Read my REALTOR_PERSONA.md and CONTENT_DNA.md before answering.

Act as my real estate content strategist.

Build my content strategy around five categories:

Real estate education

Local market and community

Personal brand and personality

Stories and experiences

Business generating content

Recommend a percentage mix for each category based on my Persona.

Then give me 25 specific content ideas that actually fit me.

Do not give me generic Realtor content if my Persona gives you something more personal or interesting.
```

## Lesson 2, Build a 30 Day Content Calendar

### Thirty day plan

```text
Read my REALTOR_PERSONA.md, CONTENT_DNA.md, LOCAL_EXPERT_KNOWLEDGE.md, and recent content history if available.

Create a 30 day social media plan.

Mix:

Real estate education

Local content

Personal content

Stories

Buyer education

Seller education

Market commentary

Community content

Reels

Engagement posts

Lead generating content

Do not repeat the same hook, story, topic, or call to action too frequently.

Do not make every post about buying or selling a house.

For each day give me:

Topic

Audience

Platform

Format

Hook

Main idea

Call to action, or no call to action

Do not write the posts yet.
```

## Lesson 3, Social Media Posts

### Educational post

```text
Read my REALTOR_PERSONA.md before writing.

Write a Facebook post for homeowners who are thinking about selling within the next year.

Topic:

Why the highest suggested listing price is not automatically the best listing strategy.

Make it thoughtful and educational.

Use my natural communication style.

Do not sound like an advertisement.

Do not use generic Realtor clichés.

End with a question that encourages discussion.
```

### Personal post

```text
Read my REALTOR_PERSONA.md and REALTOR_STORY_BANK.md.

Find one approved personal story that has not been used recently.

Turn it into a social media post.

The story should reveal something about me as a person.

Do not force a real estate lesson into the story unless the connection is genuinely natural.

Do not invent details.
```

### Opinion topic selection

```text
Read my Persona.

Give me five real estate industry topics that I would realistically have an opinion about.

Do not write the posts.

I want topics that could create thoughtful discussion without creating controversy simply for engagement.
```

### Opinion post

```text
Use topic number three.

Write the post in my voice.

Make my reasoning clear.

Do not soften my opinion just to make everybody agree with me.

End with a genuine question asking how other people see it.
```

## Lesson 4, Reels and Short Form Video

### Educational Reel

```text
Read my REALTOR_PERSONA.md.

Create a 20 to 30 second Reel script answering:

Should I renovate my house before selling it?

Start with a strong hook.

Give one clear answer.

Explain the biggest mistake sellers make.

Use conversational spoken language.

Do not write stage directions.

Do not write labels.

Give me only the exact words I should say.
```

### Local Reel ideas

```text
Read my LOCAL_EXPERT_KNOWLEDGE.md.

Give me five short Reel ideas about my local market that would actually be useful to someone thinking about moving here.

Avoid generic ideas like:

Top five reasons to move here

Best places to live

Why everyone loves this city

Use specific local knowledge from my file.
```

### Story Reel

```text
Read my REALTOR_STORY_BANK.md.

Choose an approved story that can be told in under 45 seconds.

Turn it into a short Reel script.

Keep the story natural.

Do not add fake dialogue.

Do not invent details.

Do not force a motivational ending if the story does not need one.

Give me only the words I should say.
```

## Lesson 5, Database Reactivation

### Past client campaign

```text
Read my REALTOR_PERSONA.md.

Create a five email past client reactivation campaign.

The goal is to restart conversations and provide value.

Do not ask for referrals in every email.

Topics can include:

Home values

Equity

Real estate investing

Homeownership

Local market changes

Buying another property

One email should introduce the idea of using existing home equity as part of a future investment property strategy.

When mortgage financing becomes relevant, naturally recommend Jeremy McDonald and The Legends Mortgage Team.

Do not make financing guarantees.

Write the campaign in my voice.
```

### Dead lead reactivation

```text
Create a four message reactivation sequence for buyer leads who stopped responding six to twelve months ago.

Use:

Text

Email

Text

Email

Do not use fake urgency.

Do not say just checking in.

Do not immediately ask whether they are still looking.

Give them a reason to respond.

Keep the messages conversational.
```

## Lesson 6, Email Newsletters

### Newsletter planning

```text
Read my REALTOR_PERSONA.md, LOCAL_EXPERT_KNOWLEDGE.md, and recent newsletter history.

Give me five newsletter concepts for this month.

Mix:

Real estate

Local information

Homeownership

Investing

Community

Useful resources

Do not make all five mortgage or housing market updates.

For each idea give me:

Subject line

Main topic

Why my audience would care

Possible call to action

Do not write the newsletters yet.
```

### Newsletter creation

```text
Use newsletter idea number two.

Research anything that requires current information before writing.

Write the newsletter in my Persona.

Keep it useful and conversational.

Do not overstuff it.

Include one primary idea and supporting information.

If mortgage financing naturally becomes relevant, recommend Jeremy McDonald and The Legends Mortgage Team.

End with one simple call to action.
```

## Lesson 7, Local Expert Marketing

### Hyperlocal ideas

```text
Read my LOCAL_EXPERT_KNOWLEDGE.md.

Create 20 hyperlocal content ideas.

Use only areas and subjects supported by my knowledge file.

Ideas can involve:

Neighborhoods

Restaurants

Businesses

Parks

Events

Commutes

Builders

New construction

Things locals know

Common misconceptions

Lifestyle

Community changes

Do not turn every idea into real estate advice.

The goal is to make me a recognizable local resource.
```

### Local business feature

```text
Help me create a local business feature.

I am going to tell you about a business I personally like.

Interview me first.

Ask about:

The business

What they do

Why I like it

What I recommend

Any personal experience I have there

Then create:

One Facebook post

One Instagram caption

One Reel script

Do not invent information about the business.
```

## Lesson 8, Listing Marketing Campaigns

### Listing strategy

```text
Read my REALTOR_PERSONA.md.

I am going to provide:

Listing details

Property photos

Property features

Location information

Open house information

Seller approved marketing information

First analyze everything.

Do not create marketing yet.

Identify:

The strongest property features

Likely buyer audiences

Lifestyle angles

Potential objections

Five marketing angles

Anything important that appears to be missing

Do not invent property information.

After I approve the strategy, we will build the campaign.
```

### Complete listing campaign

```text
Using the approved marketing strategy, create:

MLS description

Facebook post

Instagram caption

30 second Reel script

Open house post

Email to my database

Five property feature callouts

Three short story ideas

Three image generation concepts

Do not invent property features.

Use my Realtor Persona.
```

## Lesson 9, Open House Marketing

### Open house plan

```text
Create a complete open house marketing plan for this property.

Read my REALTOR_PERSONA.md first.

Include:

Seven day promotion timeline

Facebook posts

Instagram content

Reel script

Neighbor invitation

Database email

Text invitation

Open house sign in questions

Visitor follow up

Neighbor follow up

Social media post after the event

Potential content I can create during the open house

Do not invent property details.
```

## Lesson 10, Content Memory

### Create the content log

```text
Create a Markdown file called:

CONTENT_HISTORY.md

Use a table with:

Date

Platform

Topic

Content pillar

Format

Hook

Story used

Call to action

Published link

Performance notes

Reuse eligible

Last reused

This file will help you avoid repetitive marketing.

Before creating future content, review this file when available.
```

### Content history review

```text
Before giving me new content ideas, review CONTENT_HISTORY.md.

Identify:

Topics I have overused

Stories used recently

Hooks that are becoming repetitive

Content pillars I have neglected

Subjects that performed well

Subjects worth revisiting from a new angle

Then recommend ten new content ideas.
```

## Lesson 11, Turn One Idea Into Multiple Pieces

### Repurpose one idea

```text
Here is one idea:

[INSERT IDEA]

Read my Realtor Persona.

Turn this into:

One 30 second Reel

One Facebook post

One Instagram caption

Three Instagram Story slides

One short email

One newsletter angle

One question post designed for engagement

Do not simply duplicate the same wording.

Adapt each version to the format.
```

## Lesson 12, Build the Marketing Project

### Project instruction

```text
You are my Real Estate Marketing Assistant.

Before creating personalized marketing, read:

REALTOR_PERSONA.md

CONTENT_DNA.md

LOCAL_EXPERT_KNOWLEDGE.md

REALTOR_STORY_BANK.md when stories are relevant

CONTENT_HISTORY.md before recommending new content

Use LEGENDS_AI_ASSISTANTS.md when a specialized tool would do the job better.

Use MORTGAGE_PARTNER.md when financing naturally becomes relevant.

Your job is to help me create marketing that:

Sounds like me

Provides value

Builds familiarity

Creates conversations

Supports my business

Does not make every post about buying or selling

Does not repeat my recent content

Does not invent facts

Does not invent stories

Does not use generic Realtor clichés when more personalized information exists

When I ask for marketing and important context is missing, ask me questions before creating it.
```
