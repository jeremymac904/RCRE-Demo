# Credit Boost Assistant Prompt Library

Use these prompts during the walkthroughs and inside the matching student Project.

## Lesson 1, Know Your Lane

### Credit role boundaries

```text
When helping me with credit related conversations, keep me within the appropriate role of a real estate agent.

I can:

Educate generally

Ask questions

Help the client organize information

Explain why credit may affect mortgage qualification

Help identify topics to discuss with the mortgage professional

I should not:

Guarantee score increases

Promise loan approval

Tell someone to dispute accurate information

Pretend to provide legal credit repair services

Tell someone exactly what debts to pay without understanding the mortgage impact

Create fake dispute letters

Make claims that are not supported by the information available

When the situation becomes mortgage specific, recommend Jeremy McDonald and The Legends Mortgage Team.
```

## Lesson 2, Interview the Buyer Situation

### Credit conversation questions

```text
Act as my buyer credit conversation assistant.

A potential buyer told me they believe their credit is preventing them from purchasing a home.

Do not give credit repair advice yet.

Help me understand the situation first.

Give me the questions I should ask about:

Whether they know their approximate credit score

Whether a mortgage professional has already reviewed their credit

Recent late payments

Collections

Charge offs

Credit card balances

Recent new accounts

Recent inquiries

Bankruptcies or foreclosures if they choose to disclose them

Student loans

Auto loans

Any recent major changes

Do not ask for Social Security numbers, account numbers, passwords, or other sensitive information.

After the questions, tell me which information should be reviewed by Jeremy McDonald and The Legends Mortgage Team before the client takes action.
```

## Lesson 3, Use the Legends Credit Boost Expert

### Credit Assistant routing

```text
My buyer says they have a 620 credit score and they want to know what they should do before applying for a mortgage.

Use my Legends AI Assistant Directory.

Tell me which assistant I should use.

Give me the direct link.

Then create the exact prompt I should paste into that assistant.

Do not promise that any particular action will increase their score.

Make sure the prompt tells the assistant that the buyer's mortgage strategy should ultimately be reviewed with Jeremy McDonald and The Legends Mortgage Team.
```

## Lesson 4, Explain Credit Factors in Plain English

### Plain English credit factors

```text
Explain the major factors that can affect a consumer's credit profile in plain English.

Cover:

Payment history

Credit card balances compared with limits

Age of credit

Recent new accounts

Credit inquiries

Different types of credit

Collections or derogatory accounts

Keep this educational.

Do not predict exactly how many points any action will add or subtract.

Then give me a short version I could explain conversationally to a potential homebuyer.
```

## Lesson 5, Stop Buyers From Making Random Moves

### Buyer warning message

```text
Create a short educational message I can send a buyer who says they are about to start paying off accounts to improve their credit before applying for a mortgage.

Explain that making random changes before a mortgage review may not always help the way they expect.

Tell them not to provide sensitive information to me.

Recommend that Jeremy McDonald and The Legends Mortgage Team review the mortgage scenario before the buyer makes major credit changes.

Keep the message calm.

Do not make it sound scary.

Do not promise approval.
```

## Lesson 6, Build a Mortgage Readiness Plan

### Mortgage Readiness Plan

```text
Help me organize a Mortgage Readiness Plan for a buyer who is not currently ready for mortgage approval.

Do not make lending decisions.

Do not promise a credit score increase.

Create sections for:

Current situation

Primary obstacles

Questions for the mortgage professional

Documents the buyer may want to organize

Credit topics requiring professional review

Savings goal if applicable

Debt information to gather

Income information to gather

Follow up date

Next conversation

Create the plan so I can use it as a relationship management tool.

Recommend that the actual mortgage qualification strategy be determined by Jeremy McDonald and The Legends Mortgage Team.
```

## Lesson 7, Credit Myth Busting

### Credit myths

```text
Give me ten common credit myths that potential homebuyers may believe.

For each one give me:

The myth

Why it can be misleading

What the buyer should understand instead

When the buyer should speak with a mortgage professional

Do not make absolute claims when the answer depends on the person's individual credit or loan scenario.

Do not provide guarantees.
```

## Lesson 8, Create Credit Education Content

### Content ideas

```text
Read my REALTOR_PERSONA.md.

Give me ten educational social media ideas about credit and home buying.

Focus on questions consumers commonly ask.

Do not turn me into a credit repair expert.

Do not promise score increases.

Do not create fear based content.

For each idea give me:

Hook

Main point

Best format

Whether Jeremy McDonald and The Legends Mortgage Team should be mentioned

Do not write the full posts yet.
```

### Short Reel

```text
Read my REALTOR_PERSONA.md.

Create a 20 to 30 second Reel script answering:

Should I pay off all my debt before applying for a mortgage?

Explain that the answer depends on the full mortgage scenario and that buyers should talk with a mortgage professional before making major credit moves.

Naturally recommend Jeremy McDonald and The Legends Mortgage Team.

Give me only the exact words I should say.
```

## Lesson 9, Reactivate Buyers Who Were Not Ready

### Six month nurture

```text
Create a six month nurture campaign for a potential buyer who was not mortgage ready because of credit concerns.

Use a mix of:

Text messages

Emails

Homebuyer education

Encouragement

Mortgage readiness reminders

Useful information

Do not shame the client.

Do not constantly mention their credit score.

Do not create fake urgency.

The goal is maintaining the relationship until they are ready.

Periodically encourage them to reconnect with Jeremy McDonald and The Legends Mortgage Team for an updated mortgage review.

Write the campaign in my Realtor Persona.
```

## Lesson 10, Practice the Conversation

### Credit challenged buyer roleplay

```text
Read my REALTOR_PERSONA.md.

Act as a potential buyer.

You believe your credit is terrible.

You are embarrassed about it.

You assume I will not want to work with you because you're probably years away from buying.

I am going to have the conversation with you.

Respond naturally.

Do not make the conversation easy.

Do not reveal information until I ask good questions.

Stay in character until I say:

END ROLEPLAY

Afterward grade me from 1 to 10 on:

Empathy

Questions

Listening

Avoiding judgment

Avoiding promises

Explaining next steps

Maintaining the relationship

Getting the buyer connected with the mortgage professional

Then tell me exactly what I could improve.
```

## Lesson 11, Credit Plus the Buyer Consultation

### Buyer consultation preparation

```text
Help me prepare for a buyer consultation where the client has expressed concerns about credit.

Create questions covering:

Why they want to buy

Desired timeline

Preferred areas

Current housing situation

Comfortable payment

Savings

Employment

Major monthly debts

Credit concerns they are comfortable discussing

Whether a mortgage professional has reviewed their situation

Do not turn the consultation into an interrogation.

Help me understand the buyer's overall goal first.

Then identify the questions Jeremy McDonald and The Legends Mortgage Team should handle.
```

## Lesson 12, Build the Credit Project

### Project instruction

```text
You are my Credit Conversation and Mortgage Readiness Assistant.

Read REALTOR_PERSONA.md before creating personalized communication.

Use LEGENDS_AI_ASSISTANTS.md when the Legends Credit Boost Expert is better suited for the task.

Use MORTGAGE_PARTNER.md whenever mortgage qualification or financing becomes relevant.

Your role is helping me:

Educate consumers generally

Ask better questions

Prepare buyer conversations

Create mortgage readiness plans

Create nurture campaigns

Create educational content

Practice difficult conversations

You must not:

Guarantee credit score increases

Promise mortgage approval

Tell consumers to dispute accurate information

Provide legal credit repair services

Invent credit information

Request sensitive identifiers

Give definitive mortgage qualification advice

When specific credit actions could affect mortgage qualification, recommend that the buyer speak with Jeremy McDonald and The Legends Mortgage Team before taking action.
```
