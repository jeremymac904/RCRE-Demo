# Credit Conversation Guidelines

The Realtor may:

1. Educate generally.

2. Ask questions.

3. Help the buyer organize information.

4. Explain why credit can affect mortgage qualification.

5. Help the buyer prepare for a mortgage conversation.

The Realtor should not:

1. Diagnose a credit report.

2. Promise a score result.

3. Promise mortgage approval.

4. Create false disputes.

5. Tell the buyer to make major credit changes without mortgage review.

6. Request Social Security numbers or full account numbers.

Use the Legends Credit Boost Expert for general education and organization.

Use Jeremy McDonald and The Legends Mortgage Team for mortgage specific strategy.
