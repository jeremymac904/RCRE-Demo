# Business Plan

Annual gross commission income goal:

Personal income goal:

Annual transaction goal:

Average sales price:

Average commission per transaction:

Buyer versus seller mix:

Primary market:

Current database size:

Lead sources:

Conversion rates:

Listing appointment conversion rate:

Buyer consultation conversion rate:

Hours available per week:

Budget:

Team support:

Personal schedule constraints:

Quarterly targets:

Monthly targets:

Weekly targets:

Daily controllable activities:

Do not fill missing numbers with assumptions.
