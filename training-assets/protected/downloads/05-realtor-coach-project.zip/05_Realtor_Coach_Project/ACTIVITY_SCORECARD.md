# Activity Scorecard

| Week | Conversations | New leads | Follow ups | Appointments set | Appointments held | Agreements signed | Contracts written | Contracts accepted | Closings | Past client contacts | Referral partner conversations | Prospecting hours | Administrative hours |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|

## Review questions

1. Does the activity support the annual goal?

2. Which leading indicator is behind?

3. What activity produced the best result?

4. What is the agent avoiding?

5. What should stop, continue, or increase?
