# Bookkeeping and Self Employed Clients Prompt Library

Use these prompts during the walkthroughs and inside the matching student Project.

## Lesson 1, Organize Your Real Estate Business

### Bookkeeping categories

```text
Act as my real estate bookkeeping organization assistant.

I am a self employed real estate agent.

Help me create a simple bookkeeping category structure for my business.

Include categories for:

Commission income

Referral income

Advertising

Lead generation

MLS fees

Association dues

Brokerage fees

Transaction fees

Photography

Videography

Virtual staging

Signs

Lockboxes

Open houses

Client gifts

CRM

Software

AI tools

Website

Phone

Internet

Office expenses

Education

Coaching

Professional services

Accounting

Legal

Vehicle related expenses

Travel

Meals

Marketing events

Contract labor

Assistants

Other reasonable real estate business categories

Do not give me tax advice.

The goal is organization.

Then create a simple monthly bookkeeping checklist.
```

## Lesson 2, Clean Up the Chaos

### Transaction categorization

```text
I am going to provide a list of business transactions.

Help me organize them into bookkeeping categories.

For each transaction give me:

Merchant

Amount

Suggested category

Whether the category is obvious or uncertain

Any question I should answer before categorizing it

Do not make tax deductibility decisions.

If you are uncertain, flag it for my accountant or bookkeeper.

Do not invent information.
```

## Lesson 3, Find Recurring Expenses

### Subscription review

```text
Review the expense information I provide.

Identify recurring expenses.

Group them into:

Essential

Useful

Questionable

Potentially redundant

Needs review

Look specifically for duplicate tools or subscriptions that may perform similar functions.

Do not cancel anything.

Do not assume a service is unnecessary just because you do not recognize it.

Give me the questions I should ask before deciding whether to keep each questionable expense.
```

## Lesson 4, Understand Where Your Money Goes

### Business performance summary

```text
Using the income and expense information I provide, create a simple business performance summary.

Show me:

Total income

Total expenses

Estimated operating profit before taxes

Largest expense categories

Recurring monthly expenses

Marketing spend

Technology spend

Lead generation spend

Brokerage and transaction costs

Average revenue per closing if I provide closing count

Average operating expense per closing if enough information is available

Do not provide tax advice.

Do not invent missing numbers.

Then give me five questions I should be asking about the financial health of my business.
```

## Lesson 5, Budget Around the Business Plan

### Spending alignment review

```text
Read my real estate business plan first.

Then review the business expenses and budget I provide.

Evaluate whether my spending supports my stated goals.

Separate spending into:

Revenue producing

Client service

Necessary operations

Education and development

Convenience

Low value or questionable

Do not automatically tell me to cut expenses.

Tell me whether each major expense appears aligned with the business plan.

If I am spending heavily on tools, marketing or branding while underinvesting in the activities required to generate appointments and clients, point that out clearly.
```

## Lesson 6, Prepare for the Accountant

### Accountant meeting checklist

```text
Help me prepare for a meeting with my accountant or bookkeeper.

Using the information I provide, create:

A list of income records I should organize

A list of expense records I should organize

Questions about unclear transactions

Questions about business structure

Questions about estimated taxes

Questions about retirement planning

Questions about vehicle and mileage records

Questions about home office records if applicable

Questions about contractors or assistants

Questions about large purchases

Do not answer the tax questions yourself.

Create a clean meeting preparation checklist.
```

## Lesson 7, Self Employed Buyers Are Different

### Self employed buyer questions

```text
Help me prepare for a conversation with a self employed buyer.

I am the Realtor.

I am not the mortgage professional or accountant.

Give me appropriate questions I can ask about:

How long they have been self employed

Type of business

How they are paid

Whether they file business and personal tax returns

Whether income has changed recently

Whether they have significant business expenses

Whether they have already spoken with a mortgage professional

Whether they are planning major tax or business changes before buying

Do not tell me how much income they qualify with.

Do not provide tax advice.

Identify the questions that should be handled by Jeremy McDonald and The Legends Mortgage Team.
```

## Lesson 8, Do Not Tell Clients to Change Their Taxes

### Business revenue versus qualifying income

```text
Create a simple explanation for a self employed buyer who says:

My business makes plenty of money, so why is qualifying for a mortgage complicated?

Explain that mortgage qualification may depend on documented income and the specific loan program.

Explain that business revenue is not automatically the same as qualifying personal income.

Do not provide tax advice.

Do not tell the borrower to change deductions.

Do not tell the borrower how to file taxes.

Recommend that Jeremy McDonald and The Legends Mortgage Team review the actual financial documentation and available loan options.
```

## Lesson 9, Build a Self Employed Buyer Document Checklist

### Organization checklist

```text
Create a general organization checklist for a self employed homebuyer preparing to speak with a mortgage professional.

Possible categories may include:

Personal identification

Business information

Recent personal tax returns when applicable

Business tax returns when applicable

Year to date profit and loss statement when applicable

Business bank statements when applicable

Personal bank statements

Asset information

Debt information

Business ownership information

CPA or tax preparer contact information

Other documents that may help explain income

Clearly state that the exact documentation depends on the loan program and borrower situation.

Do not represent this as a lender requirement checklist.

Tell the buyer to confirm required documents with Jeremy McDonald and The Legends Mortgage Team.
```

## Lesson 10, Alternative Mortgage Options

### Alternative options explanation

```text
A self employed buyer says their tax returns do not appear to show enough income for the home they want to purchase.

Help me explain that traditional conventional financing may not be the only possible option.

Mention generally that alternative mortgage programs may exist for certain borrowers, including programs that evaluate income differently.

Do not quote rates.

Do not invent qualification requirements.

Do not promise approval.

Do not recommend a specific program without mortgage review.

Recommend that Jeremy McDonald and The Legends Mortgage Team evaluate the complete scenario and available lending options.
```

## Lesson 11, Create Self Employed Buyer Content

### Content ideas

```text
Read my REALTOR_PERSONA.md.

Give me ten educational content ideas specifically for self employed homebuyers.

Focus on common questions and misunderstandings.

Do not turn me into a mortgage or tax expert.

For each idea give me:

Hook

Main point

Best format

Whether Jeremy McDonald and The Legends Mortgage Team should be included

Do not write the full content yet.
```

### Short Reel

```text
Read my REALTOR_PERSONA.md.

Create a 20 to 30 second Reel script answering:

Can self employed people get mortgages?

Keep the answer simple.

Explain that self employment itself is not the problem.

Documentation and how income is evaluated matter.

Mention that there may be multiple financing options depending on the situation.

Naturally recommend Jeremy McDonald and The Legends Mortgage Team.

Give me only the exact words I should say.
```

## Lesson 12, Bookkeeping Assistant Handoff

### Bookkeeping routing

```text
I need help organizing my real estate business expenses and figuring out which monthly subscriptions I'm actually paying for.

Use my Legends AI Assistant Directory.

Tell me which assistant I should use.

Give me the direct link.

Then create the exact prompt I should paste into that assistant based on what I just asked.
```

## Lesson 13, Monthly Business Review

### Monthly review

```text
Act as my monthly real estate business review assistant.

I will provide:

Income

Expenses

Closings

Pending transactions

New leads

Appointments

Marketing spend

Lead generation spend

Technology spend

Database activity

Business plan targets

Compare actual performance to my business plan.

Tell me:

Where I am ahead

Where I am behind

What expenses deserve review

What activities appear to be producing revenue

What activities are consuming money without obvious results

What questions I should investigate

Do not automatically cut anything.

Do not give tax advice.

Then give me my three financial priorities for next month.
```

## Lesson 14, Build the Bookkeeping Project

### Project instruction

```text
You are my Real Estate Bookkeeping Organization Assistant.

Read REALTOR_PERSONA.md before personalized communication.

Your role is helping me:

Organize business income and expenses

Create bookkeeping categories

Review recurring expenses

Prepare information for my accountant or bookkeeper

Understand basic business performance

Compare business spending with my business plan

Prepare self employed buyer conversations

Create educational content

You are not my CPA.

You are not my tax advisor.

You are not my mortgage professional.

Do not provide definitive tax advice.

Do not determine tax deductibility.

Do not tell a buyer how to file taxes.

Do not calculate mortgage qualifying income unless an authorized mortgage professional provides the methodology.

Use LEGENDS_AI_ASSISTANTS.md when the specialized Bookkeeping Assistant is appropriate.

Use MORTGAGE_PARTNER.md when a self employed buyer needs mortgage qualification or financing analysis.
```
