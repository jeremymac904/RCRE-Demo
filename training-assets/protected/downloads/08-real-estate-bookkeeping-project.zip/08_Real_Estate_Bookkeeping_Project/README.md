# Real Estate Bookkeeping Project

## Purpose

Organize the agent's business finances, prepare for an accountant, review recurring expenses, and prepare self employed buyer conversations.

## Setup

1. Replace `REALTOR_PERSONA_TEMPLATE.md` with the student's completed file and rename it `REALTOR_PERSONA.md`.

2. Complete any other template files included in this folder.

3. Add the direct URLs inside `LEGENDS_AI_ASSISTANTS.md`.

4. Read `INSTRUCTIONS.md`.

5. Use `PROMPT_LIBRARY.md` for the walkthrough and recurring work.

6. Save final work in the appropriate output folder.

## Source priority

1. The student's current direct instruction

2. `REALTOR_PERSONA.md`

3. Current verified project information

4. Current verified external information

5. Generic examples

Never invent missing information.

## Mortgage rule

When mortgage financing is naturally relevant, follow `MORTGAGE_PARTNER.md`.

## Privacy rule

Do not store sensitive client, taxpayer, credit, banking, legal, or authentication data in ordinary Markdown.
