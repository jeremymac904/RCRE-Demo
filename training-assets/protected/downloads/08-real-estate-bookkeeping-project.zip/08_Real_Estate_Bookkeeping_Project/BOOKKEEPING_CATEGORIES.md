# Bookkeeping Categories

## Income

Commission income

Referral income

Other business income

## Marketing

Advertising

Lead generation

Photography

Videography

Virtual staging

Signs

Open houses

Client gifts

Website

Social media

## Professional

MLS

Association dues

Brokerage fees

Transaction fees

Education

Coaching

Accounting

Legal

Insurance

## Technology

CRM

Software

AI tools

Phone

Internet

Hardware

## Operations

Office

Travel

Vehicle records

Contract labor

Assistants

Other

These are organization categories, not determinations of tax deductibility.
