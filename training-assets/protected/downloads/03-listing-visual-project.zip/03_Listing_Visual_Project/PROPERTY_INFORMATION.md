# Property Information

Address:

City:

State:

ZIP:

List price:

Property type:

Bedrooms:

Bathrooms:

Square footage:

Lot size:

Year built:

Garage:

Pool:

Waterfront:

View:

HOA:

CDD:

Verified upgrades:

Verified features:

Known defects:

Open house date:

Open house time:

Seller approved marketing information:

Information that must not be published:

Missing information:

Do not fill any blank with an assumption.
