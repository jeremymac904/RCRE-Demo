# Visual Style

Use the agent's verified brand assets when available.

## Desired qualities

1. Clean

2. Premium

3. Mobile readable

4. Property remains the visual focus

5. Minimal unnecessary text

6. Strong hierarchy

7. Consistent typography

8. Accurate architecture and condition

## Brand assets

Logo:

Primary color:

Secondary color:

Accent color:

Preferred fonts:

Brokerage requirements:

Do not invent branding when the assets are not provided.
