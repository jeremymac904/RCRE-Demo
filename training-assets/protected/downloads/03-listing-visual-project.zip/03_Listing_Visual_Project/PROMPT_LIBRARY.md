# Listing Marketing and Visuals Prompt Library

Use these prompts during the walkthroughs and inside the matching student Project.

## Lesson 1, Let AI Analyze the Listing First

### Listing analysis

```text
Read my REALTOR_PERSONA.md first.

I am going to upload the property information and listing photos.

Do not create marketing yet.

Analyze everything I provide.

Identify:

The strongest property features

The rooms or photos that should receive the most attention

Potential lifestyle angles

Potential buyer audiences

Features that may need additional explanation

Visual weaknesses in the current photography

Opportunities for virtual staging

Opportunities for additional graphics

Five possible marketing angles

Anything important that appears to be missing

Do not invent property information.

If you cannot verify something from the listing information or photos, tell me.
```

## Lesson 2, Improve the Photo Strategy

### Photography shot list

```text
Review the property information and photos I provided.

Act as an experienced real estate photography director.

Create a photography shot list for this property.

Include:

Essential exterior shots

Essential interior shots

Feature detail shots

Lifestyle shots

Community or amenity shots if supported by the listing information

Suggested order for the final listing gallery

Rooms that need additional photography

Features that deserve close up photography

Do not suggest photographing features that are not confirmed.
```

## Lesson 3, Use the Listing Visual Assistant

### Router test

```text
I just listed a property and I want to create professional visual marketing assets from the listing photos.

I need graphics for Facebook, Instagram, Stories, and an open house.

Use my Legends AI Assistant Directory.

Tell me which specialized assistant I should use.

Give me the direct link.

Then create the exact prompt I should paste into that assistant based on this listing.
```

## Lesson 4, Virtual Staging

### Master staging prompt

```text
Virtually stage this room.

Preserve the actual property exactly as photographed.

Do not change:

Walls

Windows

Doors

Flooring

Ceiling

Lighting fixtures

Built in features

Cabinetry

Fireplace

Room dimensions

Camera angle

Architectural features

Stage the room in a warm modern luxury style.

Use furniture that realistically fits the scale of the room.

Maintain realistic perspective, shadows, lighting, and proportions.

The finished image should look like professional real estate photography.

Do not make structural changes.

Do not add permanent property features that do not exist.
```

## Lesson 5, Try Different Staging Styles

### Style comparison

```text
Using the same original room photo, create three separate virtual staging concepts.

Version one:

Modern coastal

Version two:

Warm contemporary

Version three:

Transitional luxury

Preserve every permanent property feature exactly as shown in the original photograph.

Only change furniture, rugs, artwork, plants, and removable decor.

Keep furniture scale realistic.

Do not make structural changes.
```

## Lesson 6, Decluttering and Visual Cleanup

### Declutter

```text
Create a cleaned up marketing version of this room.

Remove only temporary clutter and removable personal items.

Preserve:

Furniture unless I specifically ask for removal

Walls

Windows

Doors

Flooring

Fixtures

Built ins

Cabinetry

Permanent property features

Architecture

Camera angle

Do not renovate the property.

Do not replace materials.

Do not add features that do not exist.

The goal is simply to create a cleaner, less cluttered presentation of the same room.
```

## Lesson 7, Furniture Removal

### Furniture removal

```text
Remove the furniture and removable decor from this room.

Create a realistic vacant version of the exact same space.

Preserve all permanent features.

Do not change:

Walls

Windows

Doors

Flooring

Ceiling

Fixtures

Cabinetry

Built ins

Room dimensions

Camera position

Lighting conditions

Do not renovate or redesign the property.
```

## Lesson 8, Create Listing Graphics

### Just Listed graphic prompt

```text
Read my REALTOR_PERSONA.md.

Using the uploaded listing photo and verified property information, create a concept for a square social media graphic.

Purpose:

Just Listed announcement.

Include only:

JUST LISTED

Property city or neighborhood

Price if I provide it

One strong verified property feature

My name

My contact information

Keep the property photo as the visual focus.

Use a premium real estate aesthetic.

Do not invent property information.

Do not overcrowd the graphic.

Give me the complete image generation prompt.
```

### Open House graphic prompt

```text
Using this listing photo, create a premium open house social media graphic concept.

Include:

OPEN HOUSE

Verified date

Verified time

Property address

My name

My contact information

Use my Realtor Persona and brand direction when available.

Keep the home as the primary visual.

Do not cover important property features with text.

Do not add unverified property claims.

Give me the complete image generation prompt.
```

## Lesson 9, Create Vertical Story Assets

### Story slides

```text
Create a vertical 9 by 16 Instagram and Facebook Story concept using this listing photo.

Use the verified property information I provide.

Create three Story slides.

Slide one:

Strong visual hook

Slide two:

Three verified property highlights

Slide three:

Call to action with my contact information

Keep all important text inside mobile safe areas.

Do not invent features.

Give me an image generation prompt for each slide.
```

## Lesson 10, Turn Listing Photos Into a Reel Plan

### Property Reel plan

```text
Review all of the listing photos and verified property information.

Create a 30 second vertical property Reel plan.

Tell me:

Which photos or clips should appear

The order

Approximate duration of each visual

On screen text

Transitions

Motion effects

Where to use subtle zooms or movement

Music style

A short voiceover script

End with my contact information.

Do not invent property features.

Do not use generic phrases such as dream home or this one won't last unless I specifically ask for them.
```

## Lesson 11, Build a Property Feature Graphic Series

### Feature series

```text
Review the verified listing information.

Identify the five strongest visually marketable features.

Create five separate social media graphic concepts.

Each graphic should focus on only one feature.

For each concept give me:

The property photo to use

Headline

Short supporting text

Recommended layout

Image generation instructions

Do not repeat the same message five different ways.

Do not invent features.
```

## Lesson 12, Create Interactive Listing Content

### Engagement ideas

```text
Using this listing and my Realtor Persona, give me ten social media engagement ideas built around the property.

Examples may include:

Which kitchen style do you prefer

How would you use this room

Favorite backyard feature

Home office versus guest room

Design choices

Neighborhood lifestyle

Buyer questions

Do not invent property information.

Do not make every idea a direct sales pitch.
```

## Lesson 13, Visual Disclosure and Accuracy

### Visual accuracy instruction

```text
When creating or modifying real estate marketing images:

Never remove a permanent defect simply to make the property more attractive.

Never add a permanent property feature that does not exist.

Never change the apparent size of a room.

Never create a fake view from a window.

Never materially change the architecture.

Never misrepresent the condition of the property.

Clearly identify virtually staged or materially AI modified images when required by MLS, brokerage, advertising, or platform rules.

When uncertain whether an edit is appropriate for real estate advertising, flag it for human review.
```

## Lesson 14, Build the Listing Visual Project

### Project instruction

```text
You are my Listing Visual and Marketing Assistant.

Before creating personalized work, read:

REALTOR_PERSONA.md

Then review:

PROPERTY_INFORMATION.md

PHOTO_INDEX.md

VISUAL_STYLE.md

Use LEGENDS_AI_ASSISTANTS.md when another specialized Legends AI assistant should handle part of the workflow.

Never invent information about a property.

Never modify permanent property features unless I explicitly request an image concept that clearly represents a proposed renovation rather than the current property.

Preserve original listing photos.

Never overwrite original files.

Keep generated and edited assets separate.

When virtual staging is requested, preserve architecture and permanent property features.

When marketing claims require information not contained in PROPERTY_INFORMATION.md, ask me.

When mortgage financing becomes relevant, use MORTGAGE_PARTNER.md.

Your job is to help me turn one listing into a complete visual marketing package while accurately representing the property.
```
