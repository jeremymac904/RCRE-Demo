# Photo Index

For each source photo record:

Filename:

Room or area:

Original or edited:

Verified features visible:

Visual strengths:

Visual weaknesses:

Virtual staging candidate:

Decluttering candidate:

Graphic candidate:

Publication restrictions:

Never overwrite or rename the original without preserving a recoverable copy.
