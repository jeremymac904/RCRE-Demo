# Written Information Security Plan Checklist

This checklist does not replace a compliant security plan or professional review.

Address:

1. Risk assessment

2. Responsible person

3. Devices

4. Access controls

5. Multifactor authentication

6. Password practices

7. Client document storage

8. Data transmission

9. Remote work

10. Vendor security

11. Backups

12. Incident response

13. IRS and state reporting contacts

14. Data retention

15. Secure disposal

16. Employee training

17. Annual review

18. Recovery test
