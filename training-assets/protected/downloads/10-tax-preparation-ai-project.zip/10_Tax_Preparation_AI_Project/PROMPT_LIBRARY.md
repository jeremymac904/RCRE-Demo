# Bonus Tax Preparation Side Hustle Prompt Library

Use these prompts during the walkthroughs and inside the matching student Project.

## Lesson 1, What You Actually Need to Prepare Taxes for Money

### Current IRS research

```text
Research the current IRS requirements for becoming a paid federal income tax return preparer.

Use only current official IRS sources.

Explain:

PTIN requirements

Current PTIN fee

Annual Filing Season Program

Continuing education requirements

Representation rights

Enrolled Agent credential

Electronic filing requirements

EFIN

Do not rely on blogs or tax preparation companies.

Give me links to the official IRS pages and identify anything that may change annually.
```

## Lesson 2, Florida and Multistate Disclosure

### Required disclosure

```text
FLORIDA AND MULTISTATE DISCLOSURE

This course is educational and is not legal, tax, accounting, regulatory, or licensing advice.

Federal tax return preparer requirements do not replace state, county, municipal, business registration, occupational licensing, privacy, data security, advertising, or other requirements that may apply to your business.

Students operating in Florida should independently verify current requirements applicable to their location and business structure before providing paid services.

Students outside Florida must research the requirements in their own state and local jurisdiction.

Laws, IRS rules, fees, filing requirements, and professional standards can change.

Always verify current requirements with the IRS and appropriate state and local authorities before operating.
```

## Lesson 3, PTIN Setup

### PTIN preparation checklist

```text
Help me prepare to apply for an IRS PTIN.

Use current official IRS requirements.

Create a checklist of the information and documents I should have ready before beginning the application.

Do not ask me to paste Social Security numbers, passwords, tax documents, identity verification information, or other sensitive information into this conversation.

Give me the checklist only.
```

## Lesson 4, Should You Complete the Annual Filing Season Program

### Compare the paths

```text
Compare these two paths for someone starting a small tax preparation business:

Path one:

PTIN only.

Path two:

PTIN plus the IRS Annual Filing Season Program.

Use current official IRS information.

Compare:

Training

Continuing education

Cost considerations

Public directory visibility

Representation rights

Credibility

Annual requirements

Do not tell me which one I must choose.

Help me understand the tradeoffs.
```

## Lesson 5, EFIN and Electronic Filing

### PTIN versus EFIN

```text
Explain the difference between:

PTIN

EFIN

Electronic Return Originator

Authorized IRS e file provider

Explain it for somebody opening their first small tax preparation business.

Use current official IRS sources.

Also explain the federal e filing rule involving preparers who reasonably expect to file eleven or more covered returns.

Do not oversimplify exceptions.

Tell me which questions I still need to confirm with the IRS before opening.
```

## Lesson 6, Protect Taxpayer Data

### WISP preparation

```text
Using current official IRS guidance, help me understand the requirements for a Written Information Security Plan for a small tax preparation business.

Do not create a fake one page compliance document and tell me I'm finished.

Instead give me:

Required areas to address

Risk assessment questions

Employee considerations

Device security

Password and authentication considerations

Client document storage

Data transmission

Backup

Vendor security

Incident response

Data disposal

Annual review

Then identify which parts require professional legal, cybersecurity, or compliance review.
```

## Lesson 7, Rules for Using AI With Tax Information

### AI security rules

```text
When helping me operate a tax preparation business:

Do not ask me to paste or upload taxpayer Social Security numbers.

Do not request bank account numbers.

Do not request passwords.

Do not request identity verification credentials.

Do not request full unredacted tax documents unless the AI environment has been specifically approved for handling that data under the business's security and privacy requirements.

Prefer redacted or synthetic examples for training.

When sensitive taxpayer information is required for the actual tax preparation workflow, use only approved tax preparation systems and approved secure storage.

Never assume a consumer AI tool is appropriate for taxpayer data simply because it accepts file uploads.

Flag security concerns before processing sensitive information.
```

## Lesson 8, Build the Tax Preparation Business Plan

### Tax business planning interview

```text
Act as my small tax preparation business planning assistant.

Interview me one question at a time.

Learn:

My additional annual income goal

How many hours per week I can commit

Tax season availability

Types of returns I intend to prepare

Types of returns I will not accept

Target client

Existing Realtor database

Estimated price per return

Software costs

Education costs

Insurance costs if applicable

Marketing budget

Number of clients required

Client acquisition strategy

Referral strategy

Follow up strategy

Real estate cross referral opportunities

Do not create the plan until the interview is finished.

Then reverse engineer:

Revenue target

Returns required

Average revenue per client

Clients required per week during filing season

Marketing activity required

Estimated operating costs

Potential profit before taxes

Do not create unrealistic assumptions just to make my goal work.
```

## Lesson 9, Pick a Niche That Supports Real Estate

### Niche selection

```text
Read my REALTOR_PERSONA.md.

Help me identify potential tax preparation niches that naturally overlap with my real estate business.

Consider:

Real estate agents

Independent contractors

Gig workers

First time homebuyers

Homeowners

Small business owners

Landlords

Real estate investors

Property managers

Self employed professionals

Do not choose a niche only because it could generate real estate business.

Evaluate:

My credibility

Complexity of returns

Training required

Risk

Potential demand

Potential recurring revenue

Natural relationship with my existing business

Rank the best opportunities for me.
```

## Lesson 10, Build a Client Intake System

### Tax client intake workflow

```text
Help me design a simple tax preparation client intake workflow.

Do not collect actual taxpayer data in this conversation.

Design the process from:

New lead

Initial qualification

Engagement agreement

Secure document request

Document collection

Missing document follow up

Preparation

Client questions

Review

Signature

Electronic filing

Payment

Return delivery

Post filing follow up

Annual retention campaign

Identify which steps require secure tax preparation software or secure document systems rather than ordinary email or AI.
```

## Lesson 11, Use AI to Organize the Work

### Bookkeeping Assistant routing

```text
I am starting a tax preparation side business and need help organizing client bookkeeping information before tax preparation begins.

Use my Legends AI Assistant Directory.

Tell me whether the Legends Bookkeeping Assistant is appropriate.

Give me the direct link.

Then create the exact prompt I should paste into it.

Do not include taxpayer Social Security numbers, bank information, or other sensitive identifiers in the prompt.
```

## Lesson 12, Missing Document Follow Up

### Missing document messages

```text
Create a professional but conversational missing document follow up message.

The client still needs to provide:

[INSERT NON SENSITIVE DOCUMENT TYPES]

Do not mention Social Security numbers or account information in an unsecured message.

Give me:

Text message

Email

Second follow up

Final reminder

Keep the tone helpful rather than threatening.
```

## Lesson 13, Use the Tax Business to Build Relationships

### Ethical relationship plan

```text
Help me create an ethical annual relationship plan for clients who use both my tax preparation services and know me as a real estate professional.

The goal is maintaining a genuine relationship without exploiting confidential tax information.

Create appropriate touchpoints around:

Tax filing completion

Homeownership education

Real estate market updates

Investment education

Home equity education

Annual real estate review

Past client events

Referral relationships

Do not use confidential tax return information for marketing without appropriate permission.

Do not infer someone's desire or financial ability to purchase real estate from their tax information.

Create opportunities for clients to voluntarily start those conversations.
```

## Lesson 14, Investor and Landlord Tax Clients

### Investor tax marketing

```text
Help me design an educational marketing campaign for landlords and real estate investors who may need tax preparation services.

Do not give tax advice in the marketing.

Topics can include:

Keeping rental property records organized

Tracking income and expenses

Preparing documents for tax season

Separating business and personal records

Working with qualified tax professionals

Planning ahead instead of waiting until April

Create:

Three educational posts

Two Reel ideas

Two emails

One lead magnet idea

Do not make claims about specific deductions or tax savings unless verified and appropriately reviewed.
```

## Lesson 15, Tax Client to Real Estate Opportunity

### Compliant conversation starters

```text
Create five compliant conversation starters that allow tax preparation clients to voluntarily express interest in real estate services.

Possible areas:

Buying a home

Selling

Investment property

Rental property

Relocation

Home equity

Do not reference confidential tax return information.

Do not imply that I analyzed their taxes and determined they should buy property.

Make every conversation optional and client initiated.

Keep the language natural.
```

## Lesson 16, Create a Tax Preparation Marketing Plan

### Ninety day launch plan

```text
Read my REALTOR_PERSONA.md.

Create a ninety day marketing plan for launching my tax preparation side business.

Use:

Existing database

Past real estate clients

Sphere

Real estate agents

Self employed professionals

Local businesses

Social media

Email

Short form video

Referral partners

Educational workshops

Do not use spammy marketing.

Do not promise refunds.

Do not promise tax savings.

Do not imply credentials I do not have.

Clearly differentiate my Realtor services from my tax preparation services.

Give me:

Pre launch

Launch

Tax season

Post filing season

Retention strategy
```

## Lesson 17, Build the Tax Preparation AI Project

### Project instruction

```text
You are my Tax Preparation Business Assistant.

You help me operate and market a legitimate tax preparation business.

You are not the tax preparer signing the return.

You are not a CPA.

You are not an Enrolled Agent unless my Persona explicitly establishes that credential.

You are not my attorney.

You must never invent tax law.

You must never invent credentials.

You must never request sensitive taxpayer identifiers in ordinary AI conversations.

Before helping with current tax rules, verify them using current official IRS information.

Use REALTOR_PERSONA.md for my communication style and business context.

Use LEGENDS_AI_ASSISTANTS.md when another specialized assistant is appropriate.

Help with:

Business planning

Client intake design

Administrative workflows

Checklists

Client communication

Bookkeeping organization

Marketing

Educational content

Referral relationships

Annual client retention

Do not:

Promise refunds

Promise tax savings

Provide unsupported tax positions

Fabricate deductions

Encourage hiding income

Create false documents

Misrepresent my professional credentials

Use confidential taxpayer data for unrelated marketing

When tax law interpretation, representation, complex tax issues, or professional judgment exceeds my competence, recommend appropriate professional review.
```
