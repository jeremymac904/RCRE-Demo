# Tax Preparer Scope

Current credentials held:

Current PTIN status:

AFSP status:

Enrolled Agent status:

CPA status:

Attorney status:

States served:

Types of returns accepted:

Types of returns not accepted:

Professional review relationships:

Tax software:

Secure client portal:

Business insurance:

Written Information Security Plan status:

Never represent a credential as complete unless it is true and current.
