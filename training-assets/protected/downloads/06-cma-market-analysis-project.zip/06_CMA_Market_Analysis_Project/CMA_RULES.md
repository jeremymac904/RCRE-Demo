# CMA Rules

1. Start with the subject property.

2. Rank comps by relevance, not convenience.

3. Explain why each comp deserves its weight.

4. Flag missing concessions, condition, renovation, and sale information.

5. Treat active and pending properties differently from closed sales.

6. Analyze original list price, final list price, sale price, days on market, and reductions.

7. Create conservative, supportable, and aggressive ranges.

8. Do not predict the exact future sale price.

9. Do not use confidential client information in public content.

10. Verify current market data before publication.
