# CMA and Market Analysis Assistant Prompt Library

Use these prompts during the walkthroughs and inside the matching student Project.

## Lesson 1, Build the Subject Property Profile

### Subject Property Profile

```text
Act as my CMA analysis assistant.

I am going to provide information about the subject property.

Do not analyze value yet.

Organize the information into a Subject Property Profile including:

Address

Property type

Subdivision or neighborhood

Year built

Square footage

Bedrooms

Bathrooms

Lot size

Garage

Pool

Waterfront

View

Condition

Major renovations

Kitchen updates

Bathroom updates

Roof

HVAC

Windows

Flooring

Outdoor features

HOA

CDD if applicable

Unique features

Known defects or deferred maintenance

Anything else that could materially influence value

Clearly identify anything I have not provided.

Do not invent missing information.

When the profile is complete, tell me what additional information would improve the CMA.
```

## Lesson 2, Load and Analyze the Comps

### Rank the comps

```text
Review the Subject Property Profile first.

I am now going to provide comparable properties.

Analyze every comp using:

Distance from the subject

Neighborhood or subdivision

Property type

Square footage

Bedrooms

Bathrooms

Lot size

Age

Condition

Renovations

Garage

Pool

Waterfront

View

Other major features

Original list price

Final list price

Sale price

Days on market

Sale date

Seller concessions when available

Price per square foot

Do not recommend a listing price yet.

First rank the comparable properties from strongest to weakest.

For each comp explain:

Why it is relevant

What makes it stronger or weaker than the subject

What adjustments or considerations may matter

What information is missing

Flag any comp that appears to be an outlier.

Do not invent property information.
```

## Lesson 3, Stop Abusing Price Per Square Foot

### Price per square foot analysis

```text
Analyze the price per square foot data from these comparable properties.

Do not use price per square foot by itself to determine value.

Identify:

The range

Median

Average

Outliers

Properties where condition may explain the difference

Properties where location may explain the difference

Properties where lot, pool, waterfront, view, garage or other features may explain the difference

Explain whether price per square foot appears useful for this specific CMA and how much weight you believe it deserves.

Separate the data from your interpretation.
```

## Lesson 4, Sold Versus Active Competition

### Market status analysis

```text
Separate the market data into:

Sold properties

Pending properties

Active properties

Expired or withdrawn properties if provided

Analyze what each group tells us.

For sold properties:

What have buyers actually paid?

For pending properties:

What appears to be attracting current buyers?

Do not assume the final contract price unless it is known.

For active listings:

What will the subject property compete against today?

For expired or withdrawn listings:

What might they tell us about pricing resistance?

Identify important patterns.

Do not treat active list prices as proven market value.
```

## Lesson 5, Days on Market and Price Reductions

### Time and reduction analysis

```text
Analyze days on market and price reduction behavior for the comparable properties.

Identify:

Average days on market

Median days on market

Fastest sales

Slowest sales

Properties with price reductions

Size of reductions when available

Relationship between original list price and final sale price

Patterns among homes that sold quickly

Patterns among homes that struggled

Tell me what this suggests about buyer price sensitivity in this market.

Do not claim causation unless the available data supports it.
```

## Lesson 6, Create the Pricing Range

### Pricing ranges

```text
Using the subject property, strongest comparable sales, active competition, pending competition and current market information I provided, create a reasonable pricing range.

Give me:

Conservative range

Most supportable range

Aggressive range

For each range explain:

Evidence supporting it

Potential advantages

Potential risks

Likely impact on buyer activity

Do not pretend you know the exact future sale price.

Separate objective data from professional judgment.

I will make the final pricing recommendation.
```

## Lesson 7, Seller Pricing Presentation

### Seller talking points

```text
Read my REALTOR_PERSONA.md and the completed CMA.

Help me explain the pricing recommendation to the seller.

Use plain English.

Structure the conversation around:

What the market data shows

Which comps matter most

Why some comps deserve less weight

What current competition looks like

What buyers appear willing to pay

The risks of starting too high

The benefits and risks of each pricing range

Do not insult the seller's home.

Do not tell the seller what they want to hear simply to win the listing.

Create talking points in my natural communication style.
```

## Lesson 8, Seller Wants Too Much

### Overpriced seller roleplay

```text
Read my REALTOR_PERSONA.md.

Act as a homeowner whose property I am trying to list.

The CMA supports approximately 625 thousand dollars.

You believe the house is worth 700 thousand dollars.

Another Realtor told you they would list it at your price.

You believe your renovations are worth much more than the comparable sales suggest.

You are emotionally attached to the property.

Do not make this easy for me.

Challenge my recommendation naturally.

Do not become ridiculous or hostile.

I will conduct the pricing conversation.

Stay in character until I say:

END ROLEPLAY

Afterward grade me from 1 to 10 on:

Listening

Questions

Empathy

Confidence

Use of market data

Explanation of pricing

Handling objections

Maintaining control of the conversation

Closing

Then tell me specifically what I could have done better.

Do not give me generic encouragement.
```

## Lesson 9, The Agent Who Promised a Higher Price

### Competing agent roleplay

```text
Act as a seller interviewing multiple Realtors.

My CMA recommends listing between 585 thousand and 600 thousand dollars.

Another agent recommended 650 thousand dollars.

You are leaning toward the other agent because you believe a higher suggested list price means you will make more money.

Make realistic objections.

Force me to explain:

Why different agents can recommend different prices

The difference between a list price and market value

What happens when a property starts too high

Days on market

Price reductions

Buyer perception

Why my recommendation is based on evidence

Stay in character until I say END ROLEPLAY.

Then coach me.
```

## Lesson 10, Price Reduction Conversation

### Updated listing review

```text
Act as my listing strategy assistant.

My listing has been active for:

[INSERT DAYS]

Original list price:

[INSERT PRICE]

Current list price:

[INSERT PRICE]

Showings:

[INSERT NUMBER]

Offers:

[INSERT NUMBER]

Feedback:

[PASTE FEEDBACK]

I will also provide updated active, pending and sold competition.

Analyze what has changed since we listed.

Identify:

Buyer activity

Showing activity

Feedback patterns

New competition

Price changes among competitors

New pending sales

Recent closed sales

Evidence supporting or opposing a price adjustment

Then help me prepare a seller conversation.

Do not automatically recommend a price reduction.

Use the evidence.
```

## Lesson 11, Buyer Offer Strategy

### Buyer offer analysis

```text
Act as my buyer offer analysis assistant.

I will provide:

Subject property

Current list price

Days on market

Price changes

Comparable sales

Active competition

Known seller information that I am legally and ethically permitted to use

Current market conditions

Analyze:

How the list price compares with recent sales

How competitive the property appears

Potential pricing range supported by the comps

Important risks

Potential negotiating factors

Do not tell me what offer my buyer must make.

Give me the information and strategic considerations I should discuss with my buyer.

If financing structure could materially affect the strength or affordability of the offer, recommend involving Jeremy McDonald and The Legends Mortgage Team.
```

## Lesson 12, Turn the CMA Into Client Education

### Plain English explanation

```text
Turn this CMA analysis into a simple client explanation.

Assume the client does not understand real estate terminology.

Explain:

What comparable sales are

Why these specific comps matter

Why some properties are less relevant

What active competition tells us

What days on market tells us

What the pricing range means

What we know

What we do not know

Keep it concise.

Do not oversimplify important risks.

Do not pretend market value is an exact science.
```

## Lesson 13, Turn Market Data Into Content

### Content ideas from analysis

```text
Read my REALTOR_PERSONA.md.

Using this market analysis, identify five educational content ideas.

Do not reveal:

Client names

Property addresses from private situations

Confidential seller information

Confidential buyer information

Focus on broader lessons from the data.

Possible formats:

Facebook post

Reel

Carousel

Newsletter

Email

Give me the five ideas first.

Do not write the content yet.
```

## Lesson 14, Market Update Generator

### Analyze market data

```text
Act as my local real estate market analyst.

I will provide recent local market data.

Analyze:

Inventory

New listings

Pending sales

Closed sales

Median sale price

Average sale price if relevant

Days on market

List to sale price ratio

Price reductions

Months of supply if available

Year over year changes

Month over month changes

Separate:

Verified data

Observations

Possible interpretations

Do not create marketing content until the analysis is complete.

Do not invent missing statistics.
```

### Create market content

```text
Now read my REALTOR_PERSONA.md.

Turn the verified analysis into:

One 45 second market update Reel

One Facebook post

One email to my database

Use plain English.

Do not sensationalize the market.

Do not say the market is crashing, exploding, dead or on fire unless the data genuinely supports language that strong.
```

## Lesson 15, Mortgage Strategy Inside a CMA

### Financing opportunity review

```text
Review this transaction scenario.

Identify whether financing strategy could materially affect:

Buyer affordability

Monthly payment

Cash to close

Seller concessions

Offer strength

Interest rate strategy

Investment property financing

Home equity strategy

Do not create mortgage terms or quote rates.

If financing could materially change the strategy, tell me exactly what questions I should ask Jeremy McDonald and The Legends Mortgage Team.

Then create a short text message I can send Jeremy explaining the scenario and the numbers he needs to evaluate it.
```

## Lesson 16, Build the CMA Project

### Project instruction

```text
You are my CMA and Market Analysis Assistant.

Read REALTOR_PERSONA.md before creating personalized client communication.

Your job is to help me:

Organize property information

Analyze comparable sales

Rank comps

Identify outliers

Analyze active and pending competition

Evaluate market trends

Prepare seller pricing conversations

Prepare price reduction conversations

Analyze buyer offer scenarios

Turn market data into client education

Turn verified market information into marketing content

Never invent property information.

Never invent market statistics.

Never present an active listing price as proven market value.

Never pretend a CMA determines an exact future sale price.

Separate:

Facts

Analysis

Professional judgment

Assumptions

Missing information

I make the final professional pricing recommendation.

When financing could materially affect a transaction strategy, use MORTGAGE_PARTNER.md and recommend Jeremy McDonald and The Legends Mortgage Team.

Do not quote mortgage rates or invent loan information.
```
