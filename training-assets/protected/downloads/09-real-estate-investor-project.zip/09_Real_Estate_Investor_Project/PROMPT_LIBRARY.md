# Real Estate Investor Master Prompt Library

Use these prompts during the walkthroughs and inside the matching student Project.

## Lesson 1, Build the Investor Buy Box

### Investor discovery interview

```text
Act as my real estate investor discovery assistant.

I am meeting with a potential real estate investor.

Do not recommend properties yet.

Interview me one question at a time so I can build their investment buy box.

Learn:

Available investment capital

Whether this is their first investment property

Desired market

Property types

Preferred price range

Desired monthly cash flow

Long term appreciation goals

Short term versus long term strategy

Comfort with renovations

Property management plans

Desired holding period

Risk tolerance

Financing expectations

Whether they currently own a primary residence

Whether they own other investment properties

Whether they may have usable home equity

Whether they are interested in single family, condos, townhomes, multifamily or other property types

Whether they care more about cash flow, appreciation or a combination

Anything they absolutely do not want

When the interview is complete, create a concise Investor Buy Box.

Do not invent numbers.

Do not provide mortgage qualification advice.
```

## Lesson 2, Analyze a Rental Property

### Rental property analysis

```text
Act as my real estate investment analysis assistant.

Analyze this potential rental property using only the numbers I provide.

Include:

Purchase price

Estimated monthly rent

Property taxes

Insurance

HOA

CDD if applicable

Estimated maintenance

Estimated vacancy

Property management

Utilities paid by owner

Estimated repairs

Financing assumptions if provided

Estimated closing costs if provided

Calculate when enough information exists:

Gross annual rent

Estimated annual operating expenses

Estimated net operating income

Estimated monthly cash flow

Cap rate

Cash on cash return

Rent to price ratio

Break even considerations

Do not invent missing numbers.

Clearly identify assumptions.

Separate property performance from financing performance.

If financing information is needed, recommend that Jeremy McDonald and The Legends Mortgage Team evaluate the actual loan scenario.
```

## Lesson 3, Compare Multiple Investment Properties

### Property comparison

```text
Compare these investment properties side by side.

For each property evaluate:

Purchase price

Estimated rent

Estimated operating expenses

Estimated cash flow

Cap rate

Cash on cash return when enough information exists

Expected maintenance burden

HOA or CDD costs

Property condition

Potential renovation needs

Location considerations I provide

Likely tenant profile based only on information I provide

Potential risks

Do not choose a winner based on one metric.

Create a comparison table.

Then explain:

Which property appears strongest for cash flow

Which appears strongest for lower operational risk

Which may require more capital

Which has the biggest unanswered questions

Do not invent appreciation forecasts.
```

## Lesson 4, First Time Investor Education

### First investment explanation

```text
Read my REALTOR_PERSONA.md.

Create a simple educational explanation for a homeowner who is interested in purchasing their first investment property.

Explain:

How an investment property purchase differs from buying a primary residence

Why rental income matters

Why expenses matter

Cash flow

Vacancy

Maintenance

Property management

Reserves

Financing

Why the cheapest property is not automatically the best investment

Do not promise returns.

Do not give tax advice.

When financing becomes relevant, recommend Jeremy McDonald and The Legends Mortgage Team.
```

## Lesson 5, Introduce DSCR Financing

### DSCR explanation

```text
Explain DSCR investment property financing to a real estate agent in plain English.

Explain generally:

What DSCR means

Why rental income matters

Why these loans may be useful for real estate investors

Why personal income documentation may be treated differently than traditional mortgage financing

Why property cash flow matters

Why qualification still depends on lender guidelines and the complete scenario

Do not quote current rates.

Do not invent down payment requirements.

Do not promise approval.

Then give me five questions an agent should ask Jeremy McDonald and The Legends Mortgage Team when they have a potential investor client.
```

## Lesson 6, Find Investment Opportunities Inside the Database

### Past client investor campaign

```text
Read my REALTOR_PERSONA.md.

Create a past client investment opportunity campaign.

The audience is homeowners who previously purchased a primary residence through me.

The goal is to introduce real estate investing as something they may want to explore.

Do not assume they have enough equity.

Do not assume investing is appropriate for them.

The campaign should educate them about:

Owning multiple properties

Potential rental income

Long term real estate ownership

Using existing equity strategically when appropriate

Investment property financing

Create:

Three emails

Three text messages

Two social media posts

One short Reel script

When financing becomes relevant, naturally recommend Jeremy McDonald and The Legends Mortgage Team.

Keep the campaign conversational and educational.
```

## Lesson 7, Home Equity and HELOC Strategy

### Home equity conversation

```text
A past client owns their current home and is interested in purchasing an investment property.

They may have substantial equity in their primary residence.

Help me prepare the conversation.

Explain generally that some homeowners may consider:

Keeping their existing first mortgage

Evaluating a home equity line of credit or other home equity option

Using available funds toward investment capital

Financing the investment property separately

Do not recommend that they borrow against their home.

Do not assume they qualify.

Do not quote rates or terms.

Identify the information Jeremy McDonald and The Legends Mortgage Team would need to evaluate whether this strategy makes sense.

Then create a short message I can send Jeremy introducing the opportunity.
```

## Lesson 8, Build a Property Cash Flow Scenario

### Cash flow estimate

```text
Help me create a realistic rental property cash flow estimate.

I will provide the available numbers.

Include:

Gross monthly rent

Vacancy allowance

Property taxes

Insurance

HOA

CDD

Maintenance allowance

Capital expenditure allowance

Property management

Utilities paid by owner

Lawn or pool maintenance

Other recurring costs

Financing payment if provided

Calculate:

Estimated operating income

Estimated operating expenses

Estimated net operating income

Estimated cash flow after financing when financing information is available

Clearly label every assumption.

Do not make missing numbers look like facts.

Show me which assumptions have the biggest effect on the outcome.
```

## Lesson 9, Stress Test the Investment

### Stress test

```text
Stress test this investment property.

Use the numbers already provided.

Create scenarios for:

Base case

Rent ten percent lower

One month additional vacancy

Maintenance expenses twenty five percent higher

Unexpected five thousand dollar repair

Property management added if the investor originally planned to self manage

Do not change assumptions without showing me.

For each scenario show how estimated cash flow changes.

Then identify which variables create the greatest risk.

Do not predict future property values.
```

## Lesson 10, Investor Property Roleplay

### First time investor roleplay

```text
Read my REALTOR_PERSONA.md.

Act as a first time real estate investor.

You have watched a lot of real estate investing videos online.

You believe every rental should produce one thousand dollars per month in positive cash flow.

You believe buying below market value is easy.

You keep focusing only on purchase price and rent.

I am going to conduct the investor consultation.

Do not make the conversation easy.

Ask realistic questions.

Challenge my recommendations.

Stay in character until I say:

END ROLEPLAY

Afterward grade me from 1 to 10 on:

Discovery questions

Understanding investor goals

Explaining risk

Explaining expenses

Managing unrealistic expectations

Understanding the buy box

Discussing financing appropriately

Maintaining control of the conversation

Then coach me on what I should improve.
```

## Lesson 11, Investor Lead Generation Content

### Investor content ideas

```text
Read my REALTOR_PERSONA.md.

Give me 20 content ideas designed to attract current and first time real estate investors.

Mix:

Educational posts

Short Reels

Case study concepts

Property analysis content

Investment myths

Cash flow education

Local investment opportunities

Home equity conversations

DSCR education

First time investor education

Do not promise investment returns.

Do not provide tax advice.

Do not invent mortgage terms.

For each idea include:

Hook

Core lesson

Best format

Whether Jeremy McDonald and The Legends Mortgage Team should be included.
```

## Lesson 12, Turn Listings Into Investor Opportunities

### Listing investment screen

```text
Review this listing as a potential investment property.

Do not assume it is a good investment.

Using only verified information I provide, evaluate:

Purchase price

Estimated market rent

Taxes

Insurance

HOA or CDD

Property condition

Likely maintenance

Possible management requirements

Potential renovation needs

Rental restrictions if known

Important unanswered questions

Then tell me whether the property deserves deeper investment analysis.

Do not create missing numbers.

Do not make appreciation claims.

If the financing structure could materially affect the analysis, recommend involving Jeremy McDonald and The Legends Mortgage Team.
```

## Lesson 13, Portfolio Review

### Portfolio organization

```text
Act as my real estate portfolio organization assistant.

I am going to provide information about an investor's existing properties.

For each property organize:

Estimated value

Mortgage balance if provided

Estimated equity

Monthly rent

Operating expenses

Estimated cash flow

Interest rate if provided

Loan type if provided

Potential maintenance issues

Property management

Important notes

Then identify questions worth discussing about:

Equity

Cash flow

Concentration risk

Properties that may be underperforming

Potential future acquisitions

Potential disposition opportunities

Do not tell the investor to sell, refinance or borrow.

Identify opportunities for professional review.

When financing or equity strategy becomes relevant, recommend Jeremy McDonald and The Legends Mortgage Team.
```

## Lesson 14, Build the Investor Project

### Project instruction

```text
You are my Real Estate Investor Assistant.

Read REALTOR_PERSONA.md before creating personalized communication.

Your job is helping me:

Build investor buy boxes

Analyze rental properties

Compare opportunities

Organize investment assumptions

Calculate basic investment metrics

Stress test properties

Prepare investor consultations

Create past client campaigns

Create investor marketing

Organize portfolio information

Identify questions requiring specialized professional review

Do not:

Promise investment returns

Predict appreciation as fact

Give tax advice

Give legal advice

Invent property information

Invent rental income

Invent mortgage terms

Make mortgage approval decisions

Recommend borrowing against a primary residence without professional review

Use LEGENDS_AI_ASSISTANTS.md when another specialized assistant is more appropriate.

Use MORTGAGE_PARTNER.md whenever financing, DSCR, home equity, HELOCs, refinancing or mortgage qualification becomes relevant.

Jeremy McDonald and The Legends Mortgage Team should evaluate actual mortgage and financing strategies.
```
