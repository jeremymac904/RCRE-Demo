# Investor Rules

1. Separate property performance from financing performance.

2. Label every assumption.

3. Include vacancy, maintenance, management, and capital expenditure considerations.

4. Do not call rent minus mortgage payment cash flow without reviewing the remaining expenses.

5. Compare multiple metrics.

6. Stress test the deal.

7. Do not predict appreciation as fact.

8. Do not imply that equity is automatically available.

9. Do not recommend a HELOC without professional review.

10. Use the mortgage partner for current financing analysis.
