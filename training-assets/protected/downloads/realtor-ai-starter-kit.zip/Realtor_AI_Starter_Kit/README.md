# Realtor AI Starter Kit

Free starter pack for AI Advantage for Real Estate Agents.

## What is in here

| File | What it is |
|---|---|
| `TWIN_LITE.md` | The ten-minute path to your portable Realtor Persona. **Start here.** |
| `REALTOR_PERSONA_TEMPLATE.md` | Reference structure for a complete Persona |
| `AI_COMMAND_CENTER_TEMPLATE.md` | One page showing which tool does which job |
| `STARTER_PROMPTS.md` | The 20 highest-value prompts from the school |
| `MORTGAGE_PARTNER.md` | Preferred financing partner and the accuracy rules around it |

## Do this first

1. Open `TWIN_LITE.md`.
2. Run the interview prompt in ChatGPT, Claude, or Gemini.
3. Save the result as `REALTOR_PERSONA.md`.
4. Upload it into a Project and start using the prompts in `STARTER_PROMPTS.md`.

That is the whole free tier in four steps. Everything else in AI Advantage builds on
that one file.

## Rules that do not change

1. Never put passwords, Social Security numbers, bank information, full credit reports,
   or taxpayer data into an ordinary AI chat.
2. If AI does not know something about you, it should ask — not guess.
3. Verify every factual claim, property fact, market statistic, and mortgage detail
   before you publish it.
