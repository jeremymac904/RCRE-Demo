# Starter Prompts

The 20 prompts that get a real estate agent furthest, fastest.

Reproduced exactly as taught inside AI Advantage. The full library of 220 prompts is included with Premium.

---



## 1. Personalization interview

*Course 1, Lesson 1 — Settings and Personalization*

```text
I am a real estate agent and I want ChatGPT to become a better assistant for my business.

Ask me 10 short questions that will help determine the most useful personalization information to add to my ChatGPT settings.

Focus on:

My market
My business
My clients
My communication preferences
My goals
The type of work I want AI helping me with

Ask one question at a time.
```


## 2. Memory example

*Course 1, Lesson 2 — Memory*

```text
Remember that I am a real estate agent serving Northeast Florida.

When helping me with real estate marketing, use a conversational and educational style rather than generic corporate marketing language.

When mortgage financing becomes relevant, my preferred mortgage partner is Jeremy McDonald and The Legends Mortgage Team.
```


## 3. Voice brain dump

*Course 1, Lesson 3 — Voice*

```text
I'm going to give you a messy brain dump.

Don't interrupt me and don't start writing yet.

I'm going to explain something that happened with a buyer today.

When I'm finished, help me turn it into:

One educational social media post
One short Reel idea
One follow up email idea
One lesson I could add to my AI knowledge base

Do not invent anything I didn't tell you.
```


## 4. Starter Project instruction

*Course 1, Lesson 4 — Projects*

```text
This Project is my ongoing real estate business workspace.

Always use the knowledge documents in this Project before creating personalized work for me.

Do not invent facts about me, my business, my clients, my market, my listings, or my experience.

When my REALTOR_PERSONA document is available, read it before creating content in my voice.

When information is missing, ask me instead of guessing.
```


## 5. Create a simple About Me file

*Course 1, Lesson 5 — Knowledge Files*

```text
Interview me one question at a time and create a simple ABOUT_ME knowledge document for my real estate business.

Include:

Name
Brokerage
Phone
Email
Website
Primary market
Years of experience
Specialties
Ideal clients
Communication style
Personal interests I'm comfortable sharing
What makes me different

Do not invent information.

When finished, give me the document in Markdown format.
```


## 6. Improved prompt

*Course 2, Lesson 1 — Why Most AI Responses Suck*

```text
Act as my real estate marketing assistant.

Write a Facebook post for first time homebuyers in Jacksonville, Florida.

Explain why they should talk with a mortgage professional before spending weekends touring homes.

Keep it conversational and educational.

Do not make it sound like an advertisement.

Use plain English.

Keep it under 200 words.

End with a question that encourages comments.
```


## 7. Five part listing marketing example

*Course 2, Lesson 2 — The Five Part Prompt Formula*

```text
CONTEXT

I am a real estate agent in Northeast Florida and I just listed a four bedroom home in Middleburg.

GOAL

I want to create interest in the property before this weekend's open house.

AUDIENCE

Families looking for more space in Clay County.

INSTRUCTIONS

Keep the tone conversational.

Focus on lifestyle and useful property features.

Do not use cheesy phrases like dream home or won't last long.

OUTPUT

Give me:

One Facebook post

One Instagram caption

One 30 second Reel script

Three opening hooks
```


## 8. Listing appointment coach

*Course 2, Lesson 3 — Give AI a Role*

```text
Act as my listing appointment coach.

I have a seller meeting tomorrow.

Interview me about the seller, property, situation and competition.

Then help me prepare for the appointment.

Ask one question at a time.
```


## 9. Content strategist

*Course 2, Lesson 3 — Give AI a Role*

```text
Act as my real estate content strategist.

Your job is to help me create useful content that makes people in my local market want to follow me.

Do not make every post about buying or selling a house.

Help me mix real estate education, local content, personal stories, community information and personality.
```


## 10. Analyze examples

*Course 2, Lesson 4 — Give AI Examples*

```text
I'm going to give you three social media posts that sound like me.

Study them for:

Sentence length

Vocabulary

Humor

Tone

How I open posts

How I tell stories

How I explain things

How I end posts

Do not rewrite anything yet.

After reviewing them, tell me what patterns you notice in my communication style.
```


## 11. Less corporate

*Course 2, Lesson 5 — Stop Accepting the First Answer*

```text
This sounds too corporate. Rewrite it like I'm explaining this to a client sitting across from me.
```


## 12. Better hooks

*Course 2, Lesson 5 — Stop Accepting the First Answer*

```text
The body is good but the opening is weak. Do not rewrite the post. Give me five completely different hooks.
```


## 13. Reusable prompt creator

*Course 2, Lesson 10 — Save Reusable Prompts*

```text
Review the workflow we just completed.

Create a reusable master prompt that would allow me to repeat this process with a different property next time.

Use placeholders for information that changes.

Make the prompt easy enough that another real estate agent could use it without additional instructions.
```


## 14. Master Twin interview

*Course 3, Lesson 2 — Start the Twin Interview*

```text
You are going to help me build my Real Estate AI Twin.

Your only job right now is to interview me.

Ask one question at a time.

Do not create the final document until the interview is complete.

Dig deeper when one of my answers reveals something important.

I want you to understand both the real estate professional and the person.

Cover:

My name

Brokerage

Contact information

Primary market

Areas I serve

Years of experience

Real estate specialties

Ideal clients

Types of transactions I enjoy

Professional strengths

Professional weaknesses

Real estate philosophy

Sales philosophy

Client service philosophy

How I communicate

How I explain complicated topics

My personality

My sense of humor

Words and phrases I naturally use

Words and phrases I dislike

My values

My beliefs

My goals

My personal interests

My hobbies

My background

Important life experiences

Successes

Failures

Lessons I have learned

Stories I am comfortable using publicly

Community involvement

Local knowledge

Neighborhood expertise

My opinions about real estate

My content style

My preferred social platforms

My content pillars

My preferred calls to action

Things AI should never say on my behalf

Things AI should never invent about me

Ask follow up questions whenever useful.

When you believe you understand me well enough to create a high quality AI Twin, tell me the interview is complete and summarize what you learned before creating anything.
```


## 15. Generate the Persona

*Course 3, Lesson 3 — Build the Realtor Persona*

```text
Using everything you learned during our interview, create my master Realtor AI persona document.

Name the document:

REALTOR_PERSONA.md

Write it in first person whenever appropriate so another AI system can understand how I think and communicate.

Include these sections:

Identity

Professional Background

Market and Areas Served

Real Estate Expertise

Ideal Clients

Client Service Philosophy

Sales Philosophy

Communication Style

Voice and Writing Style

Personality

Humor

Values and Beliefs

Personal Background

Personal Interests

Stories and Life Experiences

Professional Successes

Professional Failures and Lessons

Local Knowledge

Content Philosophy

Content Pillars

Social Media Preferences

Calls to Action

Contact Information

Goals

Expertise Boundaries

Things AI Must Never Invent

Instructions for AI Systems

Do not invent anything.

If important information is missing, create a clearly labeled TODO instead of guessing.

The purpose of this file is to be portable across ChatGPT, Claude, Gemini, Hermes, and other AI systems.
```


## 16. Content strategy

*Course 4, Lesson 1 — Build Your Marketing Strategy*

```text
Read my REALTOR_PERSONA.md and CONTENT_DNA.md before answering.

Act as my real estate content strategist.

Build my content strategy around five categories:

Real estate education

Local market and community

Personal brand and personality

Stories and experiences

Business generating content

Recommend a percentage mix for each category based on my Persona.

Then give me 25 specific content ideas that actually fit me.

Do not give me generic Realtor content if my Persona gives you something more personal or interesting.
```


## 17. Educational post

*Course 4, Lesson 3 — Social Media Posts*

```text
Read my REALTOR_PERSONA.md before writing.

Write a Facebook post for homeowners who are thinking about selling within the next year.

Topic:

Why the highest suggested listing price is not automatically the best listing strategy.

Make it thoughtful and educational.

Use my natural communication style.

Do not sound like an advertisement.

Do not use generic Realtor clichés.

End with a question that encourages discussion.
```


## 18. Master staging prompt

*Course 5, Lesson 4 — Virtual Staging*

```text
Virtually stage this room.

Preserve the actual property exactly as photographed.

Do not change:

Walls

Windows

Doors

Flooring

Ceiling

Lighting fixtures

Built in features

Cabinetry

Fireplace

Room dimensions

Camera angle

Architectural features

Stage the room in a warm modern luxury style.

Use furniture that realistically fits the scale of the room.

Maintain realistic perspective, shadows, lighting, and proportions.

The finished image should look like professional real estate photography.

Do not make structural changes.

Do not add permanent property features that do not exist.
```


## 19. Coach operating rule

*Course 7, Lesson 1 — Configure a Coach That Pushes Back*

```text
Act like a real coach, not a supportive AI assistant.

Your responsibility is helping me reach the goals established in my business plan.

Do not automatically agree with my ideas.

When I tell you I want to add a new marketing strategy, lead source, technology tool, event, project or activity, evaluate it against my actual business plan.

Ask:

Does this directly support my revenue goal?

Is this likely to generate conversations, appointments, relationships, listings, buyers or closings?

What activity will this replace?

How much time will this require?

Is this productive work or productive looking busy work?

Am I avoiding an uncomfortable revenue generating activity by choosing something easier?

Is there evidence this strategy works in my market or business model?

Could I accomplish the same result more simply?

If something does not meaningfully contribute to my goals, tell me.

If I am using planning, marketing, technology, branding, social media or AI as an excuse to avoid prospecting and human conversations, call me out.

Do not be rude.

Do be direct.

My goal is results, not validation.
```


## 20. Rank the comps

*Course 8, Lesson 2 — Load and Analyze the Comps*

```text
Review the Subject Property Profile first.

I am now going to provide comparable properties.

Analyze every comp using:

Distance from the subject

Neighborhood or subdivision

Property type

Square footage

Bedrooms

Bathrooms

Lot size

Age

Condition

Renovations

Garage

Pool

Waterfront

View

Other major features

Original list price

Final list price

Sale price

Days on market

Sale date

Seller concessions when available

Price per square foot

Do not recommend a listing price yet.

First rank the comparable properties from strongest to weakest.

For each comp explain:

Why it is relevant

What makes it stronger or weaker than the subject

What adjustments or considerations may matter

What information is missing

Flag any comp that appears to be an outlier.

Do not invent property information.
```
