# Attorney Review Checklist

Have a qualified attorney review:

1. Whether the planned services are covered

2. Federal disclosures

3. Florida disclosures

4. Service agreement

5. Description of services

6. Pricing

7. Billing timing

8. Advance fee restrictions

9. Cancellation rights

10. Cancellation form

11. Refund language

12. Business address and service information

13. Advertising claims

14. Guarantees

15. Record retention

16. Privacy

17. Consumer complaints

18. Bond and trust account issues

19. Telemarketing

20. Multistate operations

Do not open for paid covered services based only on an AI generated document.
