# Legends AI Assistant Directory

## How to use this directory

When the user asks for a task that one of these specialized assistants handles better:

1. Tell the user which assistant fits.

2. Give the direct URL.

3. Create the exact prompt the user should paste.

4. Use the current Realtor Persona and request when writing the prompt.

5. Never invent a link.

6. If the link is missing, say that the direct link must be added.

## My Realtor AI Twin Generator

Purpose:

Interviews the agent and creates portable knowledge documents for ChatGPT Projects, Claude Projects, Gemini Gems, Hermes, and other AI systems.

URL:

`PASTE_DIRECT_URL_HERE`

Use for:

Persona interviews, local knowledge, story banks, content DNA, and portable AI identity files.

## Real Estate Marketing Pro

Purpose:

Creates personalized social media, Reels, newsletters, email campaigns, database reactivation, listing marketing, open house promotion, and local content.

URL:

`PASTE_DIRECT_URL_HERE`

## Listing Visual GPT Builder

Purpose:

Helps analyze property photos and create listing visual concepts, image prompts, graphics, Reels plans, open house assets, and listing campaign visuals.

URL:

`PASTE_DIRECT_URL_HERE`

## Staging Studio

Purpose:

Virtually stages rooms, removes furniture, declutters, tests design styles, and creates before and after concepts while preserving the actual property.

URL:

`PASTE_DIRECT_URL_HERE`

## Legends Realtor Coach

Purpose:

Business planning, daily activity planning, prospecting, scripts, roleplay, objection handling, accountability, listing appointments, buyer consultations, and coaching.

URL:

`PASTE_DIRECT_URL_HERE`

## CMA Companion

Purpose:

Organizes subject property information, compares comps, identifies outliers, analyzes market data, prepares pricing conversations, and creates client explanations.

URL:

`PASTE_DIRECT_URL_HERE`

## Legends Credit Boost Expert

Purpose:

General credit education, credit conversation preparation, mortgage readiness planning, action plan organization, and questions for a mortgage professional.

URL:

`PASTE_DIRECT_URL_HERE`

## Legends Bookkeeping Assistant

Purpose:

Organizes real estate business income and expenses, recurring subscriptions, monthly reviews, accountant preparation, and self employed business records.

URL:

`PASTE_DIRECT_URL_HERE`

## Legends Real Estate Investor Master

Purpose:

Builds investor buy boxes, analyzes rental properties, compares investments, organizes cash flow assumptions, stress tests deals, and prepares investor conversations.

URL:

`PASTE_DIRECT_URL_HERE`

## Required handoff response

Use this structure:

```text
There is a specialized Legends AI assistant for that task.

Assistant:
[ASSISTANT NAME]

Use it here:
[DIRECT URL]

Copy this prompt into it:

[PERSONALIZED PROMPT]
```

Do not send the user to another assistant when the current Project can perform the task well.
