# Bonus Credit Services Side Hustle Prompt Library

Use these prompts during the walkthroughs and inside the matching student Project.

## Lesson 1, Understand What Credit Repair Actually Is

### Federal research

```text
Research the current federal requirements for operating a credit repair organization.

Use current official sources from:

The Federal Trade Commission

United States Code

Consumer Financial Protection Bureau

Explain:

The Credit Repair Organizations Act

Required disclosures

Written contract requirements

Cancellation rights

Advance payment restrictions

Advertising restrictions

Prohibited practices

Consumer rights

Record keeping requirements

Do not use blogs or credit repair companies as the legal authority.

Separate current federal requirements from best practices.
```

## Lesson 2, Florida Credit Services Requirements

### Required Florida disclosure

```text
FLORIDA CREDIT SERVICES DISCLOSURE

This course is educational and is not legal or regulatory advice.

Florida regulates Credit Service Organizations under Florida Statutes Chapter 817, Part Three.

A person accepting compensation for certain services intended to improve a consumer's credit record, history or rating may be subject to these requirements.

Florida requirements include written consumer disclosures, written contracts, cancellation rights, record retention requirements and restrictions on business practices.

Florida currently provides consumers a five day cancellation period for covered credit service contracts.

Federal law may impose additional or stricter requirements.

Students should have their business model, contracts, disclosures, billing practices and advertising reviewed by a qualified Florida attorney before providing paid credit repair services.

Students outside Florida must research the requirements of every state where they intend to provide services.

Do not assume Florida requirements apply everywhere.
```

### Florida law research

```text
Research the current Florida Credit Service Organization requirements under Florida Statutes Chapter 817, Part Three.

Use the current Florida Legislature statutes as the primary source.

Explain:

Who may qualify as a Credit Service Organization

Prohibited acts

Written disclosure requirements

Contract requirements

Five day cancellation rights

Record retention

Surety bond and trust account provisions

Penalties and consumer remedies

Do not give me a compliance checklist based on assumptions.

Identify anything that should be reviewed by a Florida attorney before launching the business.
```

## Lesson 3, What You Cannot Promise

### Credit services guardrail

```text
When helping me operate a credit services business:

Never promise a specific credit score increase.

Never promise mortgage approval.

Never promise removal of accurate negative information.

Never recommend disputing information known to be accurate.

Never create false identity theft claims.

Never suggest creating a new credit identity.

Never recommend CPN schemes.

Never create false documents.

Never misrepresent what the service can accomplish.

Clearly separate:

Credit education

Disputing potentially inaccurate information

Credit rebuilding strategies

Mortgage specific credit strategy

When mortgage qualification is the goal, recommend that Jeremy McDonald and The Legends Mortgage Team review the mortgage scenario before major credit actions are taken.
```

## Lesson 4, Contracts and Cancellation Rights

### Attorney review checklist

```text
Help me prepare a checklist for an attorney who will review my credit services business documents.

Based on current federal law and Florida law, identify issues the attorney should review involving:

Consumer disclosure statement

Service agreement

Description of services

Pricing

Billing timing

Cancellation rights

Cancellation form

Refund language

Business address

Service timeframe

Advertising claims

Guarantees

Record retention

Privacy

Consumer complaints

Surety bond and trust account issues if relevant

Do not draft documents and tell me they are legally compliant.

Create the attorney review checklist.
```

## Lesson 5, Billing

### Pricing models for legal review

```text
Help me design possible pricing models for a credit services business that respect the requirement that covered credit repair services are not charged before those services are fully performed.

Do not tell me a pricing structure is legally compliant.

Instead create possible operational models for attorney review.

For each model explain:

What service is performed

When it is completed

When an invoice could potentially be generated

What documentation proves completion

How the customer sees what was performed

How refunds and cancellations would be handled

Flag any model that may create advance fee concerns.
```

## Lesson 7, Build the Client Intake Process

### Credit client intake

```text
Help me design a credit services client intake workflow.

Do not request actual sensitive consumer information.

Create the process for:

New lead

Initial education

Eligibility screening

Required disclosures

Service agreement

Cancellation period

Secure credit report access

Client goals

Document collection

Credit report review

Identification of potentially inaccurate information

Consumer authorization

Service delivery

Service completion documentation

Billing

Progress communication

Mortgage readiness review when appropriate

Completion

Ongoing education

Identify which parts require secure systems rather than ordinary email or consumer AI.
```

## Lesson 8, AI and Consumer Credit Data

### AI privacy rules

```text
When assisting with consumer credit information:

Do not request Social Security numbers.

Do not request passwords.

Do not request bank account numbers.

Do not request identity verification credentials.

Do not request full unredacted credit reports in an AI environment that has not been approved for that information.

Use redacted examples whenever possible.

Remove unnecessary personal identifiers before AI analysis.

Never retain sensitive consumer information simply because it may be useful later.

Follow the business's approved privacy, cybersecurity and document retention procedures.

When uncertain whether data should be placed into AI, require human review.
```

## Lesson 9, Use the Credit Boost Assistant

### Credit Boost routing

```text
I have a consumer who wants help understanding their credit and becoming mortgage ready.

Use my Legends AI Assistant Directory.

Tell me whether the Legends Credit Boost Expert is appropriate.

Give me the direct link.

Then create the exact prompt I should give the assistant.

Do not include sensitive personal identifiers.

Do not promise a score increase.

Make sure mortgage specific decisions are referred to Jeremy McDonald and The Legends Mortgage Team.
```

## Lesson 10, Credit Report Review Workflow

### Redacted credit review

```text
Using a properly redacted credit report or credit summary, help me organize the information.

Categorize items into:

Accounts appearing current

Late payment history

Collections

Charge offs

High revolving balances

Recent inquiries

Potential duplicate information

Information the consumer says may be inaccurate

Information requiring additional documentation

Do not automatically recommend disputes.

Do not assume an item is inaccurate.

Create questions for the consumer to investigate.

Clearly distinguish between:

Potential reporting error

Accurate negative information

Credit utilization issue

Payment history issue

Mortgage specific issue
```

## Lesson 11, Build a Client Action Plan

### Credit action plan

```text
Create a credit improvement action plan based only on the verified information I provide.

Separate actions into:

Potential reporting errors requiring investigation

Payment history issues

Credit utilization considerations

Account management considerations

Documentation to gather

Consumer education

Questions for creditors or credit bureaus

Questions for a mortgage professional

Do not guarantee outcomes.

Do not predict exact score changes.

Do not tell the consumer to dispute accurate information.

If the consumer's primary goal is mortgage qualification, identify which actions should be reviewed with Jeremy McDonald and The Legends Mortgage Team before being implemented.
```

## Lesson 12, Mortgage Readiness Creates Real Estate Opportunities

### Mortgage readiness follow up

```text
Create an ethical follow up workflow for a credit services client whose stated goal is purchasing a home.

Build touchpoints around:

Credit progress

Mortgage readiness

Savings

Homebuyer education

Understanding payments

Preparing documentation

Connecting with a Realtor

Connecting with a mortgage professional

Do not pressure the consumer into buying a home.

Do not promise mortgage approval.

When appropriate, recommend Jeremy McDonald and The Legends Mortgage Team for an updated mortgage review.
```

## Lesson 13, Turn Credit Leads Into Long Term Relationships

### Twelve month relationship campaign

```text
Create a twelve month relationship campaign for credit services clients.

Mix:

Credit education

Financial organization

Homeownership education

Mortgage readiness

Savings

Real estate investing education

Home maintenance

Local real estate information

Personal follow up

Do not constantly sell.

Do not shame consumers about credit.

Do not promise results.

Make the communication useful enough that the client wants to remain connected.
```

## Lesson 14, Market the Credit Services Business

### Ninety day marketing plan

```text
Read my REALTOR_PERSONA.md.

Create a ninety day marketing plan for a new credit services business.

Focus on:

Credit education

Credit report awareness

Mortgage readiness

First time buyers

Consumers rebuilding after financial setbacks

Self employed consumers

Past clients

Social media

Email

Short form video

Educational workshops

Referral partners

Do not promise score increases.

Do not guarantee deletions.

Do not promise mortgage approval.

Do not advertise removal of accurate negative information.

Do not use fear based claims.

Create:

Pre launch

Launch

Ongoing educational marketing

Client retention

Real estate cross referral opportunities
```

## Lesson 15, Credit Education Workshops

### Consumer workshop

```text
Create a sixty minute consumer workshop called:

Credit and the Road to Homeownership

The audience is consumers who want to understand credit and prepare for eventually buying a home.

Include:

Credit report basics

Credit score basics

Common myths

Accurate versus inaccurate information

Consumer dispute rights

Credit utilization

Payment history

Mortgage readiness

What not to do before applying for a mortgage

When to speak with a mortgage professional

Create:

Agenda

Teaching outline

Slides outline

Audience questions

Take home checklist

Follow up email

Include Jeremy McDonald and The Legends Mortgage Team as the preferred mortgage education resource.

Do not turn the workshop into a sales pitch.
```

## Lesson 16, Referral Partners

### Referral partner categories

```text
Help me identify legitimate referral partner categories for a credit education and credit services business.

For each category explain:

Why the relationship could make sense

What value I can provide them

What value they may provide clients

Potential compliance concerns

Whether consumer consent is needed before sharing information

How the relationship could also create real estate opportunities

Do not design kickback arrangements.

Do not assume referral compensation is legal.

Flag compensation arrangements for legal review.
```

## Lesson 17, Build the Business Plan

### Credit services business plan

```text
Act as my credit services business coach.

Interview me one question at a time.

Learn:

My additional income goal

Available hours per week

Market area

Target client

Pricing concept

Services I intend to offer

Services I will not offer

Marketing budget

Existing Realtor database

Mortgage relationships

Potential referral partners

Education required

Legal review budget

Software expenses

Customer acquisition strategy

Capacity

When the interview is finished, build a twelve month business plan.

Reverse engineer:

Revenue goal

Clients required

Completed services required

Marketing activity

Expected operating expenses

Break even point

Weekly activity targets

Do not invent assumptions just to make my goal work.

Push back if the business model appears unrealistic or noncompliant.
```

## Lesson 18, Build the Credit Services AI Project

### Project instruction

```text
You are my Credit Services Business Assistant.

You help me operate and market a legitimate credit education and credit services business.

You are not an attorney.

You are not a mortgage underwriter.

You do not promise credit outcomes.

Before providing current legal or regulatory guidance, verify current official federal and state sources.

Read:

FEDERAL_CREDIT_REPAIR_RULES.md

FLORIDA_CREDIT_SERVICES_DISCLOSURE.md

AI_DATA_SECURITY_RULES.md

before helping with covered credit repair operations.

Use REALTOR_PERSONA.md for my communication style.

Use LEGENDS_AI_ASSISTANTS.md when the specialized Credit Boost Assistant is appropriate.

Use MORTGAGE_PARTNER.md when mortgage readiness or financing becomes relevant.

Never:

Promise score increases

Guarantee deletion of information

Recommend disputing information known to be accurate

Create false identity theft claims

Create false documents

Recommend CPNs or alternate identities

Collect advance fees contrary to applicable law

Invent regulatory requirements

Misrepresent my credentials

Store sensitive consumer identifiers in ordinary AI files

When the law, contract, disclosure, billing practice or advertising claim is uncertain, require qualified legal review.
```
