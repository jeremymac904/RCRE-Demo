# Realtor AI Twin Lite

**What this is:** the free-tier starting point for AI Advantage. It is Course 3,
*Build Your Realtor AI Twin*, Lessons 1 through 3 — nothing added, nothing invented.

**What it produces:** one file, `REALTOR_PERSONA.md`.

That is the same file the full Twin produces, in the same format, read by the same
Projects. Twin Lite is a smaller starting point, **not a different system**. When you
upgrade, you keep the Persona you already built and add documents around it.

---

## What you get vs. the full Twin

| Document | Twin Lite | Full Twin (Course 3 complete) |
|---|---|---|
| `REALTOR_PERSONA.md` — who you are, how you talk, what AI must never invent | Yes | Yes |
| `LOCAL_EXPERT_KNOWLEDGE.md` — your firsthand community knowledge | — | Lesson 4 |
| `REALTOR_STORY_BANK.md` — your real, approved stories | — | Lesson 5 |
| `CONTENT_DNA.md` — your content pillars and balance | — | Lesson 6 |
| `LEGENDS_AI_ASSISTANTS.md` — the specialist routing directory | — | Lesson 7 |
| `MORTGAGE_PARTNER.md` — the financing referral rule | — | Lesson 8 |
| AI Router — decides which tool should do the job | — | Lesson 9 |
| `AI_COMMAND_CENTER.md` — one page that ties it together | — | Lesson 10 |
| Twin testing and portability | — | Lessons 11-12 |

Twin Lite gets you an AI that stops giving you generic Realtor answers.
The full Twin gets you an AI that also knows your market, your stories, your content
strategy, and which specialist tool to hand you.

---

## Do this in three steps

### Step 1 — Understand what you are building

Your AI Twin is not pretending to be you. Its job is to understand you well enough that
AI stops giving you generic real estate answers.

You are teaching it who you are, how you think, how you communicate, who you serve, what
makes you different, and what you actually know. Then you are packaging that into one
portable knowledge document that follows you into every AI tool.

### Step 2 — Let the AI interview you

Open ChatGPT, Claude, or Gemini. Paste this prompt. Answer one question at a time. Take
your time — the quality of the interview is the quality of the Persona.

```text
You are going to help me build my Real Estate AI Twin.

Your only job right now is to interview me.

Ask one question at a time.

Do not create the final document until the interview is complete.

Dig deeper when one of my answers reveals something important.

I want you to understand both the real estate professional and the person.

Cover:

My name

Brokerage

Contact information

Primary market

Areas I serve

Years of experience

Real estate specialties

Ideal clients

Types of transactions I enjoy

Professional strengths

Professional weaknesses

Real estate philosophy

Sales philosophy

Client service philosophy

How I communicate

How I explain complicated topics

My personality

My sense of humor

Words and phrases I naturally use

Words and phrases I dislike

My values

My beliefs

My goals

My personal interests

My hobbies

My background

Important life experiences

Successes

Failures

Lessons I have learned

Stories I am comfortable using publicly

Community involvement

Local knowledge

Neighborhood expertise

My opinions about real estate

My content style

My preferred social platforms

My content pillars

My preferred calls to action

Things AI should never say on my behalf

Things AI should never invent about me

Ask follow up questions whenever useful.

When you believe you understand me well enough to create a high quality AI Twin, tell me the interview is complete and summarize what you learned before creating anything.
```

### Step 3 — Generate the Persona

When the interview is finished, paste this:

```text
Using everything you learned during our interview, create my master Realtor AI persona document.

Name the document:

REALTOR_PERSONA.md

Write it in first person whenever appropriate so another AI system can understand how I think and communicate.

Include these sections:

Identity

Professional Background

Market and Areas Served

Real Estate Expertise

Ideal Clients

Client Service Philosophy

Sales Philosophy

Communication Style

Voice and Writing Style

Personality

Humor

Values and Beliefs

Personal Background

Personal Interests

Stories and Life Experiences

Professional Successes

Professional Failures and Lessons

Local Knowledge

Content Philosophy

Content Pillars

Social Media Preferences

Calls to Action

Contact Information

Goals

Expertise Boundaries

Things AI Must Never Invent

Instructions for AI Systems

Do not invent anything.

If important information is missing, create a clearly labeled TODO instead of guessing.

The purpose of this file is to be portable across ChatGPT, Claude, Gemini, Hermes, and other AI systems.
```

Save the result as `REALTOR_PERSONA.md`.

---

## Then use it

Upload `REALTOR_PERSONA.md` into any ChatGPT Project, Claude Project, or Gemini Gem and
add this Project instruction:

```text
This Project is my ongoing real estate business workspace.

Always use the knowledge documents in this Project before creating personalized work for me.

Do not invent facts about me, my business, my clients, my market, my listings, or my experience.

When my REALTOR_PERSONA document is available, read it before creating content in my voice.

When information is missing, ask me instead of guessing.
```

---

## How to tell it worked

Ask your AI these four questions from Course 3, Lesson 11. If the answers still sound
generic, your Persona needs more detail — fix the knowledge, do not settle for mediocre
output.

```text
Describe me as a real estate professional in 150 words. Do not use generic Realtor marketing language. Base everything on my Persona.
```

```text
Give me five social media topics that fit BOTH my professional expertise and my personality. Do not give me generic Realtor topics.
```

```text
Write a Facebook post in my voice about a mistake buyers commonly make. Before writing, tell me which parts of my Persona you're using.
```

```text
Tell me three things you do NOT know about me yet that would make you a better assistant.
```

---

## Upgrading to the full Twin

Nothing gets thrown away. Keep the exact same `REALTOR_PERSONA.md` and continue with
Course 3 from Lesson 4. Each remaining lesson adds one more document beside it.

---

## Rules that do not change

1. Do not invent your history, credentials, production numbers, or client stories.
2. If the AI does not know something, it should ask — not guess.
3. Never put passwords, Social Security numbers, bank information, full credit reports,
   or taxpayer data into an ordinary AI chat.
4. When information is missing, the AI writes a clearly labeled TODO instead of filling
   the gap with something plausible.
